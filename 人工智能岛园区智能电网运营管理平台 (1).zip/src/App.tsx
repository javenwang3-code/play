import React, { useState, useEffect } from 'react';
import { 
  Zap, AlertTriangle, Activity, ShieldAlert, Sliders, Wrench, 
  Clock, Sun, Moon, Cloud, ChevronDown, Check, Play, RotateCcw, 
  MapPin, Plus, Eye, BarChart3, Video, FileText, CheckCircle2, User, Settings, LogOut, ChevronRight,
  Compass, Route, Ruler, Download, Calendar
} from 'lucide-react';
import { initialPOIs, initialAlarms, initialWorkOrders, patrolRecordsMap, initialCaptures, cabinetList, simulationDetails } from './data';
import { POIPoint, Alarm, WorkOrder, PatrolMetric, CaptureItem } from './types';
import InteractiveMap from './components/InteractiveMap';
import { DonutChart, MultiLineChart, BarChart } from './components/MiniCharts';

// Import local assets
import homeBg from './assets/images/ai_park_twin_1780995308531.png';
import energyBg from './assets/images/energy_bg_1780993922493.png';
import cabinetBg from './assets/images/cabinet_bg_1780993941920.png';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'distribution' | 'energy' | 'patrol' | 'simulate' | 'ops'>('home');
  const [time, setTime] = useState<string>('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Real-time fluctuating core stats
  const [totalKwh, setTotalKwh] = useState(3.2);
  const [gridKwh, setGridKwh] = useState(2.18);
  const [pvKwh, setPvKwh] = useState(0.64);
  const [ambientTemp, setAmbientTemp] = useState(35.2);
  const [batterySOC, setBatterySOC] = useState(80);
  const [costSavings, setCostSavings] = useState(824);

  // Lists & data with live updates
  const [pois, setPois] = useState<POIPoint[]>(initialPOIs);
  const [alarms, setAlarms] = useState<Alarm[]>(initialAlarms);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(initialWorkOrders);
  const [selectedPoi, setSelectedPoi] = useState<POIPoint | null>(null);
  const [selectedCabinet, setSelectedCabinet] = useState<any>(null);
  const [selectedSubCabinetDetail, setSelectedSubCabinetDetail] = useState<any>(null);
  const [selectedEnergyAnomaly, setSelectedEnergyAnomaly] = useState<any>(null);
  const [greenAnalysisPeriod, setGreenAnalysisPeriod] = useState<'today' | 'month'>('today');
  const [activeSubChart, setActiveSubChart] = useState<'weather' | 'temp' | 'water'>('weather');
  const [activeEnergyView, setActiveEnergyView] = useState<'device' | 'stage'>('device');
  const [activeEnergyRank, setActiveEnergyRank] = useState<'enterprise' | 'building'>('enterprise');
  const [activePatrolDate, setActivePatrolDate] = useState<string>('xj-20260608');

  // Interactive UI switcher states
  const [cabMonitorTab, setCabMonitorTab] = useState<'today' | 'month'>('today');
  const [energyPeriod, setEnergyPeriod] = useState<'today' | 'month'>('today');
  const [homeEnergyPeriod, setHomeEnergyPeriod] = useState<'today' | 'month'>('today');
  const [patrolVideoTab, setPatrolVideoTab] = useState<'video' | 'drone' | 'dog'>('video');
  const [patrolCaptureTab, setPatrolCaptureTab] = useState<'video' | 'drone' | 'dog'>('video');
  
  // Simulation Controls & Output
  const [simType, setSimType] = useState<'outage' | 'leakage' | 'overload'>('outage');
  const [simTarget, setSimTarget] = useState('配电站-A (主变压器)');
  const [simIntensity, setSimIntensity] = useState(150);
  const [simDuration, setSimDuration] = useState(15);
  const [simRunning, setSimRunning] = useState(false);
  const [showSimResult, setShowSimResult] = useState(false);

  // Common Tools Dropdown & Layer Switches States
  const [isToolsMenuOpen, setIsToolsMenuOpen] = useState(false);
  const [activeHoverMenu, setActiveHoverMenu] = useState<'viewport' | 'weather_sim' | 'roam_sim' | null>(null);
  const [layerSettings, setLayerSettings] = useState({
    poi: true,             // 设备POI
    pipeline: true,        // 电力管线
    energyHeatmap: false,  // 能耗热力图
    pedestrianHeatmap: false, // 人流热力图
  });

  // User menus
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [isRoamMenuOpen, setIsRoamMenuOpen] = useState(false);
  const [toastText, setToastText] = useState<string | null>(null);
  const [showReportType, setShowReportType] = useState<'patrol' | 'ops' | null>(null);
  const [alarmStatPeriod, setAlarmStatPeriod] = useState<'today' | 'week' | 'month'>('today');
  const [selectedPatrolVideo, setSelectedPatrolVideo] = useState<string>('cam1');
  const [selectedPatrolType, setSelectedPatrolType] = useState<'route' | 'drone' | 'free'>('free');
  
  // Equipment maintenance plans state
  const [maintenancePlans, setMaintenancePlans] = useState([
    { id: 'MP-01', name: '1号主电力变压器放电试验', time: '2026-06-12 10:00', status: 'pending', desc: '主变高压侧断路安全及放电校准' },
    { id: 'MP-02', name: '储能电站A组电池放电负荷调试', time: '2026-06-15 14:00', status: 'scheduled', desc: '储能集装箱温控系统与极限充放电' },
    { id: 'MP-03', name: 'C段直流并网柜温升复阻测绘', time: '2026-06-10 16:30', status: 'overdue', desc: '由于环境温度过高，计划延迟，需排温' },
    { id: 'MP-04', name: '智能环境综合探测仪B校验', time: '2026-06-11 09:00', status: 'completed', desc: '积水及外墙湿度气敏元件参数对标' },
    { id: 'MP-05', name: '10kV环网柜联结电缆护套扫描', time: '2026-06-18 10:00', status: 'scheduled', desc: '防止雨水渗入导致电缆表层阻抗降低' }
  ]);

  // Operations reports state
  const [opsReports, setOpsReports] = useState([
    {
      id: 'REP-2026-003',
      title: '2026年6月第1周 园区智联网电力健康与能效综合报告',
      time: '2026-06-07 18:00',
      content: `一、基本情况\n本周园区总计耗电20.45万KWh，光伏绿电自给率约21.0%，能耗负荷基本在安全范围内运行。\n\n二、系统隐患及处理\n1. 发现20号楼3层夜间非正常用电偏高，判定为服务器机群温控异常。\n2. 环网柜03存在轻微超温警示，已指派工单进行柜体清灰防尘与排风扇复核。\n\n三、运维建议\n建议下一巡检周期重点对高寒高热设备执行热红外扫描，及时处理金属性轻微漏电隐患。`
    },
    {
      id: 'REP-2026-002',
      title: '2026年5月 园区储能微电网并网放电效能评估报告',
      time: '2026-05-31 16:00',
      content: `一、并网总体指标\n5月份储能并网容量累计达到6.48万KWh，削峰填谷贡献指数达89.5%。\n\n二、关键设备健康度\n电池A组温升维持在32-35℃，容量无异常衰减，B组主变分支利用率在极高峰期被拉低至85%以下，起到了良好的缓释保护作用。`
    }
  ]);
  const [previewReport, setPreviewReport] = useState<any>(null);

  // Alarm processing states
  const [alarmToProcess, setAlarmToProcess] = useState<Alarm | null>(null);
  const [selectedAssignee, setSelectedAssignee] = useState<string>('李工 (电力运维)');
  const [selectedPriority, setSelectedPriority] = useState<string>('high');
  const [selectedNotes, setSelectedNotes] = useState<string>('');

  // Map settings
  const [currentWeather, setCurrentWeather] = useState<'sunny' | 'rainy' | 'foggy'>('sunny');
  const [isDay, setIsDay] = useState(true);

  // Derived states (placed after all useState declarations)
  const displayedPois = (() => {
    if (activeTab === 'patrol' && selectedPatrolType === 'route') {
      const extraCams: POIPoint[] = [
        {
          id: 'route-cam-1',
          label: '监控摄像头-配电站',
          category: '配电站高空全景监控球机',
          status: 'normal',
          x: 35,
          y: 45,
          level: '在线 | 正常度 99%',
          voltage: '--',
          current: '--',
          temp: '--',
          lastCheck: '刚刚'
        },
        {
          id: 'route-cam-2',
          label: '监控摄像头-变压器',
          category: '主变红外成像双光谱相机',
          status: 'normal',
          x: 51,
          y: 38,
          level: '在线 | 正常度 100%',
          voltage: '--',
          current: '--',
          temp: '--',
          lastCheck: '刚刚'
        },
        {
          id: 'route-cam-3',
          label: '监控摄像头-充电桩区',
          category: '车棚快充防护测温枪机',
          status: 'normal',
          x: 61,
          y: 52,
          level: '在线 | 正常度 98%',
          voltage: '--',
          current: '--',
          temp: '--',
          lastCheck: '刚刚'
        }
      ];
      const filteredPois = pois.filter(p => !p.id.startsWith('route-cam-'));
      return [...filteredPois, ...extraCams];
    }
    return pois;
  })();

  const isPisVideo = selectedPoi ? (
    selectedPoi.label.includes('摄像头') || 
    selectedPoi.label.includes('监控') ||
    selectedPoi.label.includes('无人机') || 
    selectedPoi.label.includes('机器狗') ||
    selectedPoi.id.startsWith('route-cam-') ||
    selectedPoi.id === 'poi-4' ||
    selectedPoi.id === 'poi-5' ||
    selectedPoi.id === 'poi-6'
  ) : false;

  // Clock Update
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' }) + ' ' + now.toTimeString().split(' ')[0]);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Periodic Telemetry Fluctuations for Real-Time Dynamism
  useEffect(() => {
    const interval = setInterval(() => {
      // Fluctuating values
      setTotalKwh(prev => +(prev + (Math.random() * 0.04 - 0.015)).toFixed(2));
      setGridKwh(prev => +(prev + (Math.random() * 0.02 - 0.008)).toFixed(2));
      setPvKwh(prev => Math.max(0, +(prev + (Math.random() * 0.012 - 0.005)).toFixed(2)));
      setAmbientTemp(prev => +(prev + (Math.random() * 0.6 - 0.3)).toFixed(1));
      setCostSavings(prev => Math.round(prev + Math.random() * 2));
      setBatterySOC(prev => {
        const next = prev + (Math.random() > 0.51 ? 1 : -1);
        return Math.min(Math.max(next, 75), 95);
      });

      // Slightly fluctuate individual POI parameters
      setPois(prevPois => prevPois.map(poi => {
        if (poi.status === 'normal' && Math.random() > 0.7) {
          const voltNum = parseFloat(poi.voltage);
          const currNum = parseFloat(poi.current);
          const tempNum = parseFloat(poi.temp);
          return {
            ...poi,
            voltage: isNaN(voltNum) ? poi.voltage : `${Math.round(voltNum + (Math.random() * 4 - 2))}V`,
            current: isNaN(currNum) ? poi.current : `${Math.round(currNum + (Math.random() * 6 - 3))}A`,
            temp: isNaN(tempNum) ? poi.temp : `${(tempNum + (Math.random() * 0.4 - 0.2)).toFixed(1)}°C`
          };
        }
        return poi;
      }));
    }, 2800);

    return () => clearInterval(interval);
  }, []);

  const triggerToast = (text: string) => {
    setToastText(text);
    setTimeout(() => setToastText(null), 2500);
  };

  const currentBgImage = () => {
    if (activeTab === 'energy') return energyBg;
    if (activeTab === 'distribution') return cabinetBg;
    return homeBg;
  };

  // SVG Chart Definitions based on core fluctuating parameters
  const getPowerCurveData = () => [
    { name: '尖', points: [12, 14, 18, 15, 23, 20, 24, 28, 22, 19, 13, 10], color: '#f87171' },
    { name: '峰', points: [5, 12, 15, 20, 18, 22, 19, 15, 12, 10, 8, 4], color: '#fbbf24' },
    { name: '平', points: [20, 22, 23, 21, 24, 26, 25, 22, 21, 20, 19, 18], color: '#2dd4bf' },
    { name: '谷', points: [45, 48, 52, 49, 45, 41, 38, 42, 45, 40, 48, 46], color: '#a78bfa' }
  ];

  const getSubChartData = () => {
    switch (activeSubChart) {
      case 'temp':
        return [{ name: '环境气温', points: [26.4, 26.8, 27.2, 28.5, 29.3, 31.0, 31.8, 30.2, 29.1, 28.0, 27.2, 26.5], color: '#f87171' }];
      case 'water':
        return [{ name: '实时水位', points: [0.8, 0.9, 0.85, 0.95, 1.1, 1.35, 1.48, 1.4, 1.25, 1.05, 0.9, 0.82], color: '#38bdf8' }];
      case 'weather':
      default:
        return [{ name: '天气气象', points: [120, 240, 480, 620, 750, 820, 840, 780, 610, 420, 150, 20], color: '#fbbf24' }];
    }
  };

  const handleRunSimulation = () => {
    setSimRunning(true);
    triggerToast('正在运行高级数字孪生故障仿真评估...');
    setTimeout(() => {
      setSimRunning(false);
      setShowSimResult(true);
      triggerToast('仿真计算完成！受影响管网高亮标注');
    }, 1200);
  };

  const handleResetSimulation = () => {
    setShowSimResult(false);
    triggerToast('仿真模型已自动重置。');
  };

  const handleProcessAlarm = (alarm: Alarm) => {
    const newOrder: WorkOrder = {
      id: `WO-2026-${Math.floor(100 + Math.random() * 900)}`,
      title: `【抢修调度】${alarm.title} 应急故障排查`,
      type: 'fault',
      status: 'processing',
      assignee: '抢修电力二组',
      time: '刚刚'
    };
    setWorkOrders([newOrder, ...workOrders]);
    triggerToast(`立即派发! 工单【${newOrder.id}】已成功送达运维人员。`);
  };

  return (
    <div className="min-h-screen text-[#c8dce8] select-none font-sans overflow-hidden flex flex-col relative bg-[#040c14]">
      {/* Dynamic scanlines over background */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)+50%,rgba(0,0,0,0.25)+50%),linear-gradient(90deg,rgba(255,0,0,0.03),rgba(0,255,0,0.01),rgba(0,0,255,0.03))] bg-[length:100%_4px,3px_100%] pointer-events-none z-30 opacity-40"></div>

      {/* Futuristic Header Navbar Container */}
      <header className="h-16 border-b border-teal-500/15 bg-gradient-to-b from-[#091f2e] to-[#040d14] flex items-center justify-between px-6 z-40 relative shrink-0">
        <div className="flex items-center gap-3">
          <svg className="w-8 h-8 text-teal-400 rotate-animation" viewBox="0 0 28 28" fill="none">
            <polygon points="14,2 26,8 26,20 14,26 2,20 2,8" stroke="currentColor" strokeWidth="1.5" />
            <polygon points="14,6 22,10 22,18 14,22 6,18 6,10" fill="rgba(45,212,191,0.12)" stroke="currentColor" strokeWidth="1" />
            <circle cx="14" cy="14" r="3" fill="currentColor" />
          </svg>
          <div className="leading-tight">
            <h1 className="text-sm font-bold bg-gradient-to-r from-teal-300 via-emerald-300 to-teal-100 bg-clip-text text-transparent uppercase tracking-wider">
              人工智能岛园区智能电网运营管理平台
            </h1>
          </div>
        </div>

        {/* Desktop & Mobile Responsive Tab Strip Navigation */}
        <nav className="flex items-center h-full gap-1 ml-4 md:ml-6 mr-auto overflow-x-auto scrollbar-none whitespace-nowrap scroll-smooth">
          {[
            { id: 'home', label: '首页', icon: Zap },
            { id: 'distribution', label: '配电房', icon: Activity },
            { id: 'energy', label: '能耗', icon: BarChart3 },
            { id: 'patrol', label: '巡检', icon: Video },
            { id: 'simulate', label: '模拟', icon: Sliders },
            { id: 'ops', label: '运维', icon: Wrench },
          ].map(tab => {
            const Icon = tab.icon;
            const isTabActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setSelectedPoi(null);
                  setSelectedCabinet(null);
                }}
                className={`flex items-center gap-1.5 h-12 px-3 md:px-5 text-xs font-semibold uppercase tracking-wider transition-all duration-300 relative border-b-2 shrink-0 ${
                  isTabActive 
                    ? 'text-teal-300 border-teal-400 bg-teal-500/5' 
                    : 'text-[#81a9b3] border-transparent hover:text-teal-300 hover:bg-white/5'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span>{tab.label}</span>
                {tab.id === 'distribution' && <span className="absolute top-2 right-1 w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping"></span>}
                {tab.id === 'ops' && <span className="absolute top-2 right-1 w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping"></span>}
              </button>
            );
          })}
        </nav>

        {/* Global operational indicators */}
        <div className="flex items-center gap-4 text-xs shrink-0 relative">
          
          {/* 常用工具 (Common Tools) Dropdown Panel */}
          <div className="relative">
            <button
              onClick={() => {
                setIsToolsMenuOpen(!isToolsMenuOpen);
                setActiveHoverMenu(null);
              }}
              className="flex items-center gap-1.5 bg-slate-900 border border-teal-500/30 hover:border-teal-400/60 rounded-lg px-2.5 py-1.5 transition-colors text-teal-300 font-semibold cursor-pointer shadow shadow-teal-950/40 text-[11px] leading-none"
            >
              <Wrench className="w-3.5 h-3.5 text-teal-400 shrink-0" />
              <span>常用工具</span>
              <ChevronDown className={`w-3 h-3 text-slate-500 transition-transform duration-200 ${isToolsMenuOpen ? 'rotate-180' : ''}`} />
            </button>

            {isToolsMenuOpen && (
              <div 
                className="absolute right-0 mt-2 w-48 bg-[#07151f] border border-teal-500/40 shadow-[0_10px_25px_rgba(0,0,0,0.7)] rounded-lg py-1.5 z-55 animate-fade-in font-sans"
                onMouseLeave={() => setActiveHoverMenu(null)}
              >
                {/* 视角切换 */}
                <div 
                  className="relative group/tool"
                  onMouseEnter={() => setActiveHoverMenu('viewport')}
                >
                  <button className="flex w-full items-center justify-between px-3.5 py-2 text-xs text-slate-300 hover:bg-teal-500/10 hover:text-teal-300 transition-colors">
                    <div className="flex items-center gap-2">
                      <Eye className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                      <span>视角切换</span>
                    </div>
                    <ChevronRight className="w-3 h-3 text-slate-500 group-hover/tool:text-teal-400" />
                  </button>

                  {activeHoverMenu === 'viewport' && (
                    <div className="absolute left-full top-0 ml-1 w-36 bg-[#07151f] border border-teal-500/40 shadow-2xl rounded-lg py-1 z-55 animate-scale-up">
                      {[
                        { label: '全览', toast: '已重置数字园区全局双孪概揽视角' },
                        { label: '20号楼', toast: '微观诊断：三维视口已聚焦至 20 号办公写字楼' },
                        { label: '配电房', toast: '深穿下钻：已切换至 1号配电房内舱微网层', tab: 'distribution' }
                      ].map((item) => (
                        <button
                          key={item.label}
                          onClick={() => {
                            triggerToast(item.toast);
                            if (item.tab) {
                              setActiveTab(item.tab as any);
                            }
                            setIsToolsMenuOpen(false);
                            setActiveHoverMenu(null);
                          }}
                          className="w-full text-left px-3 py-1.5 text-xs text-slate-300 hover:text-teal-300 hover:bg-teal-500/10 transition-colors cursor-pointer"
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* 天气模拟 */}
                <div 
                  className="relative group/tool"
                  onMouseEnter={() => setActiveHoverMenu('weather_sim')}
                >
                  <button className="flex w-full items-center justify-between px-3.5 py-2 text-xs text-slate-300 hover:bg-teal-500/10 hover:text-teal-300 transition-colors">
                    <div className="flex items-center gap-2">
                      <Cloud className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                      <span>天气模拟</span>
                    </div>
                    <ChevronRight className="w-3 h-3 text-slate-500 group-hover/tool:text-teal-400" />
                  </button>

                  {activeHoverMenu === 'weather_sim' && (
                    <div className="absolute left-full top-0 ml-1 w-36 bg-[#07151f] border border-teal-500/40 shadow-2xl rounded-lg py-1 z-55 animate-scale-up">
                      {[
                        { label: '晴天', value: 'sunny', toast: '气象环境模拟：切换为晴朗天气环境' },
                        { label: '雨天', value: 'rainy', toast: '气象环境模拟：切换为微雨环境' },
                        { label: '雾天', value: 'foggy', toast: '气象环境模拟：切换为浓雾蔽障环境' }
                      ].map((item) => (
                        <button
                          key={item.value}
                          onClick={() => {
                            setCurrentWeather(item.value as any);
                            triggerToast(item.toast);
                            setIsToolsMenuOpen(false);
                            setActiveHoverMenu(null);
                          }}
                          className={`w-full text-left px-3 py-1.5 text-xs transition-colors cursor-pointer ${
                            currentWeather === item.value ? 'text-teal-300 bg-teal-500/10 font-bold' : 'text-slate-300 hover:text-teal-300 hover:bg-teal-500/10'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* 日夜切换 */}
                <div onMouseEnter={() => setActiveHoverMenu(null)}>
                  <button
                    onClick={() => {
                      const nextIsDay = !isDay;
                      setIsDay(nextIsDay);
                      triggerToast(`已调控数字孪生光影模型：切换到${nextIsDay ? '日间' : '夜间'}视照模式`);
                      setIsToolsMenuOpen(false);
                    }}
                    className="flex w-full items-center gap-2 px-3.5 py-2 text-xs text-slate-300 hover:bg-teal-500/10 hover:text-teal-300 transition-colors"
                  >
                    {isDay ? (
                      <Moon className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    ) : (
                      <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    )}
                    <span>{isDay ? '夜晚' : '白天'}</span>
                  </button>
                </div>

                {/* 添加点位 */}
                <div onMouseEnter={() => setActiveHoverMenu(null)}>
                  <button
                    onClick={() => {
                      triggerToast('三维交互标注图层加载，点击数字空间放置点位');
                      setIsToolsMenuOpen(false);
                    }}
                    className="flex w-full items-center gap-2 px-3.5 py-2 text-xs text-slate-300 hover:bg-teal-500/10 hover:text-teal-300 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                    <span>添加点位</span>
                  </button>
                </div>

                {/* 测量工具 */}
                <div onMouseEnter={() => setActiveHoverMenu(null)}>
                  <button
                    onClick={() => {
                      triggerToast('开启三维空间测距与面积测绘工具，请在地图上拉线测量');
                      setIsToolsMenuOpen(false);
                    }}
                    className="flex w-full items-center gap-2 px-3.5 py-2 text-xs text-slate-300 hover:bg-teal-500/10 hover:text-teal-300 transition-colors"
                  >
                    <Ruler className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                    <span>测量工具</span>
                  </button>
                </div>

                <div className="h-px bg-teal-500/10 my-1" />

                {/* 巡检漫游 */}
                <div 
                  className="relative group/tool"
                  onMouseEnter={() => setActiveHoverMenu('roam_sim')}
                >
                  <button className="flex w-full items-center justify-between px-3.5 py-2 text-xs text-[#8fb5bd] hover:bg-teal-500/10 hover:text-teal-300 transition-all">
                    <div className="flex items-center gap-2">
                      <Compass className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                      <span>巡检漫游</span>
                    </div>
                    <ChevronRight className="w-3 h-3 text-slate-500 group-hover/tool:text-teal-400" />
                  </button>

                  {activeHoverMenu === 'roam_sim' && (
                    <div className="absolute left-full top-0 ml-1 w-36 bg-[#07151f] border border-teal-500/40 shadow-2xl rounded-lg py-1 z-55 animate-scale-up">
                      {[
                        { label: '自由漫游', toast: '已开启第一人称视口三维自由漫游模式' },
                        { label: '无人机漫游', toast: '启动仿生无人机环绕轨迹数孪巡航' },
                        { label: '巡检路线漫游', toast: '加载智联网巡视路线仿真测绘图层', tab: 'patrol' }
                      ].map((item) => (
                        <button
                          key={item.label}
                          onClick={() => {
                            triggerToast(item.toast);
                            if (item.tab) {
                              setActiveTab(item.tab as any);
                            }
                            setIsToolsMenuOpen(false);
                            setActiveHoverMenu(null);
                          }}
                          className="w-full text-left px-3 py-1.5 text-xs text-slate-300 hover:text-teal-300 hover:bg-teal-500/10 transition-colors cursor-pointer"
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

              </div>
            )}
          </div>

          {/* Stacked Time & Date indicators (Time on top with larger font, Date below) */}
          <div className="text-slate-400 font-mono hidden md:flex items-center gap-2 bg-slate-900/40 px-2.5 py-1 rounded-lg border border-teal-500/10 shrink-0">
            <Clock className="w-3.5 h-3.5 text-teal-400" />
            <div className="flex flex-col text-right leading-none gap-0.5">
              <span className="text-[13px] font-bold text-teal-300 tracking-wide">{time.split(' ')[1] || '--:--:--'}</span>
              <span className="text-[9px] text-[#508890] font-medium">{time.split(' ')[0] || '----/--/--'}</span>
            </div>
          </div>

          {/* User drop menu */}
          <div className="relative">
            <button
              onClick={() => setUserMenuOpen(!userMenuOpen)}
              className="flex items-center gap-2 bg-slate-900 border border-teal-500/20 rounded-full px-2.5 py-1 hover:border-teal-400/40 transition-colors cursor-pointer"
            >
              <div className="w-5 h-5 rounded-full bg-teal-400 text-slate-950 flex items-center justify-center font-bold text-[10px]">
                管
              </div>
              <span className="text-[11px] text-[#c8dce8] font-medium max-w-[60px] truncate">管理员</span>
              <ChevronDown className="w-3 h-3 text-slate-500 shrink-0" />
            </button>

            {userMenuOpen && (
              <div className="absolute right-0 mt-2.5 w-40 rounded-lg p-1 bg-[#0b1b24] border border-teal-500/20 shadow-2xl z-50">
                <button className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs text-slate-300 hover:bg-teal-500/10 hover:text-teal-300 rounded" onClick={() => { setUserMenuOpen(false); triggerToast('个人中心加载中...'); }}>
                  <User className="w-3.5 h-3.5" /> <span>个人中心</span>
                </button>
                <button className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs text-slate-300 hover:bg-teal-500/10 hover:text-teal-300 rounded" onClick={() => { setUserMenuOpen(false); triggerToast('正在加载系统设置...'); }}>
                  <Settings className="w-3.5 h-3.5" /> <span>系统设置</span>
                </button>
                <div className="h-px bg-teal-500/10 my-1" />
                <button className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs text-rose-300 hover:bg-rose-500/10 hover:text-rose-400 rounded" onClick={() => { setUserMenuOpen(false); alert('退出登录演示'); }}>
                  <LogOut className="w-3.5 h-3.5" /> <span>退出登录</span>
                </button>
              </div>
            )}
          </div>

        </div>
      </header>

      {/* Main interactive grid frame */}
      <div className="flex-1 w-full relative flex overflow-hidden">
        
        {/* Full-screen Backdrop Interactive Map */}
        <div className="absolute inset-0 w-full h-full z-0">
          <InteractiveMap
            bgImage={currentBgImage()}
            pois={displayedPois}
            onPoiClick={(poi) => setSelectedPoi(poi)}
            selectedPoiId={selectedPoi ? selectedPoi.id : null}
            showAllPois={(layerSettings.poi && activeTab !== 'distribution' && activeTab !== 'simulate') || (activeTab === 'patrol' && selectedPatrolType === 'route')}
          >
            {/* Heatmap overlay when in Energy view */}
            {activeTab === 'energy' && (
              <div className="absolute inset-0 bg-[#030a0f]/40 pointer-events-none z-10 backdrop-contrast-125" style={{ mixBlendMode: 'color-burn' }} />
            )}

            {/* 1. 电力管线 overlay lines under home tab */}
            {layerSettings.pipeline && activeTab === 'home' && (
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
                {/* Glowing electric grid connection line overlays */}
                <path d="M 120 180 L 195 240 L 335 240" fill="none" stroke="#2dd4bf" strokeWidth="2.5" strokeDasharray="6,4" className="stroke-dash-animation opacity-85" />
                <path d="M 335 240 L 452 387 L 682 322" fill="none" stroke="#2dd4bf" strokeWidth="2.5" strokeDasharray="6,4" className="stroke-dash-animation opacity-85" />
                <path d="M 682 322 L 812 432 L 950 490" fill="none" stroke="#2dd4bf" strokeWidth="2.5" strokeDasharray="6,4" className="stroke-dash-animation opacity-85" />
                
                <path d="M 220 450 L 452 387 L 588 190" fill="none" stroke="#38bdf8" strokeWidth="2" strokeDasharray="5,5" className="stroke-dash-animation opacity-70" />
                <path d="M 452 387 L 788 560" fill="none" stroke="#fbbf24" strokeWidth="2" strokeDasharray="4,6" className="stroke-dash-animation opacity-65" />
              </svg>
            )}

            {/* 2. 能耗热力图 thermal blurred blobs under home tab */}
            {layerSettings.energyHeatmap && activeTab === 'home' && (
              <div className="absolute inset-0 pointer-events-none z-10">
                {/* Energy Heatspots */}
                <div className="absolute top-[35%] left-[28%] w-56 h-56 bg-amber-500/25 rounded-full blur-3xl mix-blend-screen animate-pulse" />
                <div className="absolute top-[52%] left-[64%] w-64 h-64 bg-rose-500/20 rounded-full blur-3xl mix-blend-screen animate-pulse duration-3000" />
                <div className="absolute top-[18%] left-[72%] w-44 h-44 bg-orange-500/15 rounded-full blur-2xl mix-blend-screen" />
                <div className="absolute top-[68%] left-[40%] w-48 h-48 bg-yellow-500/20 rounded-full blur-3xl mix-blend-screen animate-pulse duration-2000" />
              </div>
            )}

            {/* 3. 人流热力图 pedestrian blurred blobs under home tab */}
            {layerSettings.pedestrianHeatmap && activeTab === 'home' && (
              <div className="absolute inset-0 pointer-events-none z-10">
                {/* Pedestrian Traffic Heatspots */}
                <div className="absolute top-[42%] left-[45%] w-60 h-60 bg-teal-500/20 rounded-full blur-3xl mix-blend-screen animate-pulse duration-4000" />
                <div className="absolute top-[65%] left-[24%] w-50 h-50 bg-purple-500/20 rounded-full blur-3xl mix-blend-screen animate-pulse" />
                <div className="absolute top-[28%] left-[82%] w-44 h-44 bg-cyan-500/15 rounded-full blur-2xl mix-blend-screen" />
              </div>
            )}

            {/* Simulated Heat Highlight Ring when in Simulation screen */}
            {activeTab === 'simulate' && (
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
                {showSimResult && (
                  <>
                    <circle cx="32%" cy="45%" r="40" className="stroke-rose-500 stroke-2 fill-rose-500/25 animate-pulse" />
                    <circle cx="48%" cy="38%" r="55" className="stroke-rose-500 stroke-2 fill-rose-500/20 animate-pulse" />
                    <line x1="32%" y1="45%" x2="48%" y2="38%" stroke="#f87171" strokeWidth="4" className="stroke-dash-animation opacity-80" />
                  </>
                )}
              </svg>
            )}

            {/* Patrol route pathway overlay when in Patrol screen */}
            {activeTab === 'patrol' && selectedPatrolType === 'route' && (
              <svg 
                viewBox="0 0 100 100" 
                preserveAspectRatio="none" 
                className="absolute inset-0 w-full h-full pointer-events-none z-10"
              >
                {/* Glow/blur path */}
                <polygon
                  points="58,22 45,32 32,45 38,48 52,58 55,68"
                  vectorEffect="non-scaling-stroke"
                  fill="rgba(45,212,191,0.02)"
                  stroke="#2dd4bf"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="opacity-40 blur-[1px]"
                />
                {/* Base line */}
                <polygon
                  points="58,22 45,32 32,45 38,48 52,58 55,68"
                  vectorEffect="non-scaling-stroke"
                  fill="none"
                  stroke="#0891b2"
                  strokeWidth="1"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="opacity-60"
                />
                {/* Running dash layer */}
                <polygon
                  points="58,22 45,32 32,45 38,48 52,58 55,68"
                  vectorEffect="non-scaling-stroke"
                  fill="none"
                  stroke="#2dd4bf"
                  strokeWidth="1.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeDasharray="6, 4"
                  className="stroke-dash-animation"
                />
                {/* Animated patrol status tracking dots */}
                <circle r="0.8" fill="#67e8f9" className="animate-ping" style={{ transformBox: 'fill-box', transformOrigin: 'center' }}>
                  <animateMotion
                    dur="12s"
                    repeatCount="indefinite"
                    path="M 58 22 L 45 32 L 32 45 L 38 48 L 52 58 L 55 68 Z"
                  />
                </circle>
                <circle r="0.4" fill="#ffffff">
                  <animateMotion
                    dur="12s"
                    repeatCount="indefinite"
                    path="M 58 22 L 45 32 L 32 45 L 38 48 L 52 58 L 55 68 Z"
                  />
                </circle>
              </svg>
            )}

            {activeTab === 'patrol' && selectedPatrolType === 'drone' && (
              <svg 
                viewBox="0 0 100 100" 
                preserveAspectRatio="none" 
                className="absolute inset-0 w-full h-full pointer-events-none z-10"
              >
                {/* Dynamic drone scanning circles radiating */}
                <circle cx="48%" cy="38%" r="12" className="stroke-teal-400 stroke-[0.3] fill-none animate-pulse" />
                <circle cx="48%" cy="38%" r="6" className="stroke-teal-400/50 stroke-[0.2] fill-teal-500/5 animate-pulse" />
                <circle cx="48%" cy="38%" r="18" className="stroke-emerald-400/40 stroke-[0.2] fill-none" strokeDasharray="3,3" />
                
                {/* Target crossing markers */}
                <line x1="45%" y1="38%" x2="51%" y2="38%" stroke="#2dd4bf" strokeWidth="0.15" />
                <line x1="48%" y1="35%" x2="48%" y2="41%" stroke="#2dd4bf" strokeWidth="0.15" />
                
                <text x="50%" y="36%" className="fill-teal-300 font-mono" style={{ fontSize: '2px' }}>UAV Scan: ACTIVE</text>
              </svg>
            )}

            {activeTab === 'patrol' && selectedPatrolType === 'free' && (
              <svg 
                viewBox="0 0 100 100" 
                preserveAspectRatio="none" 
                className="absolute inset-0 w-full h-full pointer-events-none z-10"
              >
                {/* Tiny crosshairs at important inspection node regions */}
                <circle cx="28%" cy="38%" r="1.5" className="stroke-teal-500/40 stroke-[0.1] fill-none" />
                <circle cx="48%" cy="38%" r="1.5" className="stroke-teal-500/40 stroke-[0.1] fill-none" />
                <circle cx="68%" cy="38%" r="1.5" className="stroke-teal-500/40 stroke-[0.1] fill-none" />
              </svg>
            )}
          </InteractiveMap>
        </div>

        {/* Patrol screen sub-mode panels (Path, Drone, Free) overlay in the upper middle */}
        {activeTab === 'patrol' && (
          <div id="patrol-sub-modes" className="absolute top-4 left-1/2 -translate-x-1/2 z-35 flex items-center gap-1.5 bg-[#030910]/85 border border-teal-500/25 p-1 rounded-xl shadow-[0_4px_25px_rgba(0,0,0,0.6)] backdrop-blur-md pointer-events-auto leading-none font-sans text-xs">
            <button
              onClick={() => {
                setSelectedPatrolType('route');
                triggerToast('已激活【路径巡检】效果展示（绘制动态巡视路线仿真测绘图层）');
              }}
              className={`px-3.5 py-2 rounded-lg font-semibold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                selectedPatrolType === 'route' 
                  ? 'bg-gradient-to-r from-teal-500/25 to-emerald-500/25 border border-teal-400/50 text-teal-300 shadow-[0_0_12px_rgba(45,212,191,0.25)]' 
                  : 'border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              🔄 路径巡检
            </button>
            <button
              onClick={() => {
                setSelectedPatrolType('drone');
                triggerToast('已切换至【无人机巡检】模式（开启红外热探及广域覆盖扫描）');
              }}
              className={`px-3.5 py-2 rounded-lg font-semibold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                selectedPatrolType === 'drone' 
                  ? 'bg-gradient-to-r from-teal-500/25 to-emerald-500/25 border border-teal-400/50 text-teal-300 shadow-[0_0_12px_rgba(45,212,191,0.25)]' 
                  : 'border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              🛸 无人机巡检
            </button>
            <button
              onClick={() => {
                setSelectedPatrolType('free');
                triggerToast('已开启【自由巡检】模式（手动漫游、自定义视频源画面及测控）');
              }}
              className={`px-3.5 py-2 rounded-lg font-semibold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                selectedPatrolType === 'free' 
                  ? 'bg-gradient-to-r from-teal-500/25 to-emerald-500/25 border border-teal-400/50 text-teal-300 shadow-[0_0_12px_rgba(45,212,191,0.25)]' 
                  : 'border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              🚶 自由巡检
            </button>
          </div>
        )}

        {/* ----------------- LEFT SIDEBAR Telemetry PANEL (Frosted Glassmorphism Overlay) ----------------- */}
        <aside className="absolute left-4 top-4 bottom-4 w-[310px] hidden md:flex flex-col gap-4 overflow-y-auto z-20 pointer-events-auto shrink-0 select-none custom-scrollbar p-0 bg-transparent border-0 shadow-none backdrop-blur-none pb-4">
          {activeTab === 'home' && (
            <>
               {/* Comprehensive Energy Overview Card */}
               <div className="bg-[#040c14]/85 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/95 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                 <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                   <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                     <Zap className="w-4 h-4 text-teal-400" />
                     <span>能源综合概览</span>
                   </div>
                   <div className="flex border border-slate-800 p-0.5 rounded text-[9px] bg-slate-950/60 leading-none">
                     <button
                       onClick={() => setHomeEnergyPeriod('today')}
                       className={`py-1 px-1.5 rounded transition-all font-semibold cursor-pointer ${homeEnergyPeriod === 'today' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400'}`}
                     >
                       今日
                     </button>
                     <button
                       onClick={() => setHomeEnergyPeriod('month')}
                       className={`py-1 px-1.5 rounded transition-all font-semibold cursor-pointer ${homeEnergyPeriod === 'month' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400'}`}
                     >
                       本月
                     </button>
                   </div>
                 </div>
 
                 {/* Donut Graph widget */}
                 <div className="flex items-center gap-4 bg-slate-950/40 p-2.5 rounded-lg border border-slate-800/60 shadow-inner">
                   <DonutChart
                     parts={
                       homeEnergyPeriod === 'today' ? [
                         { value: 68, color: '#2dd4bf' },
                         { value: 20, color: '#34d399' },
                         { value: 12, color: '#fbbf24' }
                       ] : [
                         { value: 66, color: '#2dd4bf' },
                         { value: 21, color: '#34d399' },
                         { value: 13, color: '#fbbf24' }
                       ]
                     }
                     size={84}
                     centerText={homeEnergyPeriod === 'today' ? `${totalKwh.toFixed(1)}万` : `${(totalKwh * 30.15).toFixed(1)}万`}
                     centerSubtext="总消耗"
                   />
                   <div className="flex-1 flex flex-col gap-1.5 text-[11px] text-slate-400 font-mono">
                     <div className="flex items-center justify-between">
                       <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-teal-400"></span>市电用电</span>
                       <span className="font-bold text-teal-400">{homeEnergyPeriod === 'today' ? '68%' : '66%'}</span>
                     </div>
                     <div className="flex items-center justify-between">
                       <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>光伏集能</span>
                       <span className="font-bold text-emerald-400">{homeEnergyPeriod === 'today' ? '20%' : '21%'}</span>
                     </div>
                     <div className="flex items-center justify-between">
                       <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>储能支援</span>
                       <span className="font-bold text-amber-400">{homeEnergyPeriod === 'today' ? '12%' : '13%'}</span>
                     </div>
                   </div>
                 </div>
 
                 {/* Stat Grid */}
                 <div className="grid grid-cols-2 gap-2">
                   {[
                     { 
                       label: '市电用能', 
                       val: homeEnergyPeriod === 'today' ? `${gridKwh.toFixed(2)}` : `${(gridKwh * 30.15).toFixed(2)}`, 
                       unit: '万kWh', 
                       spec: 'text-teal-400' 
                     },
                     { 
                       label: '光伏发电', 
                       val: homeEnergyPeriod === 'today' ? `${pvKwh.toFixed(2)}` : `${(pvKwh * 30.15).toFixed(2)}`, 
                       unit: '万kWh', 
                       spec: 'text-emerald-400' 
                     },
                     { 
                       label: '储能SOC', 
                       val: homeEnergyPeriod === 'today' ? `${batterySOC}` : `${Math.min(96, batterySOC + 2)}`, 
                       unit: homeEnergyPeriod === 'today' ? '% 容量' : '% 均值', 
                       spec: 'text-amber-400' 
                     },
                     { 
                       label: homeEnergyPeriod === 'today' ? '今日省钱' : '本月省钱', 
                       val: homeEnergyPeriod === 'today' ? `¥${costSavings}` : `¥${(costSavings * 30.5).toLocaleString(undefined, { maximumFractionDigits: 0 })}`, 
                       unit: 'RMB', 
                       spec: 'text-teal-300' 
                     }
                   ].map((st, idx) => (
                     <div key={idx} className="bg-slate-950/30 border border-slate-800/40 rounded p-2 text-left">
                       <span className="text-[10px] text-slate-400 block font-medium">{st.label}</span>
                       <div className="flex items-baseline mt-1 gap-1">
                         <span className={`text-base font-bold font-mono tracking-tight ${st.spec}`}>{st.val}</span>
                         <span className="text-[8px] text-[#508890]">{st.unit}</span>
                       </div>
                     </div>
                   ))}
                 </div>
               </div>

              {/* Smooth power load plot curve Card */}
              <div className="bg-[#040c14]/85 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/95 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-1">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <Activity className="w-4 h-4 text-teal-400" />
                    <span>电能消耗实时曲线</span>
                  </div>
                </div>
                <div className="bg-slate-950/20 border border-slate-800/30 p-1.5 rounded-lg">
                  <MultiLineChart data={getPowerCurveData()} xLabels={['2h', '6h', '10h', '14h', '18h', '22h']} />
                  <div className="grid grid-cols-4 gap-1 mt-2 text-[8px] font-medium text-slate-400">
                    <div className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>尖电能</div>
                    <div className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>峰电能</div>
                    <div className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-teal-400"></span>平电能</div>
                    <div className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span>谷电能</div>
                  </div>
                </div>
              </div>

              {/* Substation Grid status indices Card */}
              <div className="bg-[#040c14]/85 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/95 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-1">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <ShieldAlert className="w-4 h-4 text-teal-400" />
                    <span>配电房状态</span>
                  </div>
                </div>
                <div className="flex justify-between items-center bg-slate-950/45 p-2 rounded border border-slate-800/60 text-center">
                  <div><div className="text-sm font-bold text-teal-300 font-mono">36</div><div className="text-[9px] text-[#508890]">总数</div></div>
                  <div><div className="text-sm font-bold text-emerald-400 font-mono">31</div><div className="text-[9px] text-[#508890]">正常</div></div>
                  <div><div className="text-sm font-bold text-amber-400 font-mono">3</div><div className="text-[9px] text-[#508890]">告警</div></div>
                  <div><div className="text-sm font-bold text-rose-400 font-mono">2</div><div className="text-[9px] text-[#508890]">断路障</div></div>
                </div>

                <div className="flex flex-col gap-1 text-[11px] text-[#a0cad4] font-mono select-none">
                  <div className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>一级中转(正常:03/故障:0)</div>
                  <div className="grid grid-cols-6 gap-1.5 text-center mt-0.5">
                    {[
                      { v: '01', details: { name: '一级中转配电柜-01', type: '一级配电设备', status: '正常', statusColor: 'text-emerald-400', voltage: '380 V', current: '112 A', temp: '32.4 °C', workload: '45%', desc: '该配电柜运行于一级并网主要进线回路，主要是科技住宅主线路中枢，输配电稳定性良好，各元件测温节点正常。' } },
                      { v: '02', details: { name: '一级中转配电柜-02', type: '一级配电设备', status: '正常', statusColor: 'text-emerald-400', voltage: '380 V', current: '128 A', temp: '33.1 °C', workload: '52%', desc: '负责科技园区A、B区动力主干输配。当前电缆接头瞬时稳态温度健康，三相平衡度达 98.7%。' } },
                      { v: '09', details: { name: '一级中转配电柜-09', type: '一级配电设备', status: '正常', statusColor: 'text-emerald-400', voltage: '381 V', current: '98 A', temp: '30.8 °C', workload: '39%', desc: '作为高阻并网微型配电节点，日常运作稳定，滤波补偿就地保护一切就绪。' } }
                    ].map((item, i) => (
                      <div key={i} className="py-1 border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 rounded text-[9px] hover:scale-105 cursor-pointer transition-transform" onClick={() => { setSelectedSubCabinetDetail(item.details); triggerToast(`打开 ${item.details.name} 数孪诊断报告`); }}>{item.v}</div>
                    ))}
                  </div>

                  <div className="flex items-center gap-1.5 mt-1.5"><span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>二级柜组(Warn:01/Err:01)</div>
                  <div className="grid grid-cols-6 gap-1.5 text-center mt-0.5">
                    <div className="py-1 border border-amber-500/30 bg-amber-500/10 text-amber-400 rounded text-[9px] hover:scale-105 cursor-pointer transition-transform" onClick={() => {
                      setSelectedSubCabinetDetail({ name: '二级负荷配电柜-03', type: '二级配电设备', status: '警告 (柜内局部异常温升)', statusColor: 'text-amber-400', voltage: '380 V', current: '210 A', temp: '72.1 °C', workload: '88%', desc: '柜内B相主要负荷线触头温度偏高超标（目前 72.1°C），极可能存在接触电阻过大或接头氧化受潮现象，已触发阈值告警。' });
                      triggerToast('打开 二级负荷配电柜-03 异常细节');
                    }}>03</div>
                    <div className="py-1 border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 rounded text-[9px] hover:scale-105 cursor-pointer transition-transform" onClick={() => {
                      setSelectedSubCabinetDetail({ name: '二级负荷配电柜-07', type: '二级配电设备', status: '正常', statusColor: 'text-emerald-400', voltage: '379 V', current: '85 A', temp: '35.1 °C', workload: '31%', desc: '负责绿化和后勤支路、动力负荷小。运行稳定，断路器处于良好的合闸状态。' });
                      triggerToast('打开 二级负荷配电柜-07 运行报告');
                    }}>07</div>
                    <div className="py-1 border border-rose-500/30 bg-rose-500/10 text-rose-400 rounded text-[9px] hover:scale-105 cursor-pointer transition-transform animate-pulse" onClick={() => {
                      setSelectedSubCabinetDetail({ name: '二级负荷配电柜-12', type: '二级配电设备', status: '故障 (严重超载运行)', statusColor: 'text-rose-400 font-bold', voltage: '365 V', current: '340 A', temp: '68.5 °C', workload: '142%', desc: '突发重载异常！受末端大功率设备启动影响，导致二次侧瞬态电流骤增至 340A。达到设计负荷容量的 1.42倍，有引发火灾安全隐患！' });
                      triggerToast('⚠️ 紧急查看 二级负荷配电柜-12 严重超载故障报告');
                    }}>12</div>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* TAB 2: 配电房 Subsystem detailed telemetry */}
          {activeTab === 'distribution' && (
            <>
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center gap-1.5 border-b border-teal-500/10 pb-2 text-xs text-teal-300 font-bold tracking-wider">
                  <ShieldAlert className="w-4 h-4 text-teal-400" />
                  <span>实时告警</span>
                </div>

                <div className="flex flex-col gap-2 max-h-[160px] overflow-y-auto">
                  {alarms.map(alarm => (
                    <div key={alarm.id} className="flex flex-col gap-2 text-left bg-slate-950/40 p-2 rounded border border-slate-800/60 text-[11px] leading-tight">
                      <div className="flex gap-2">
                        <span className={`w-1.5 h-1.5 rounded-full mt-1 shrink-0 ${alarm.level === 'emergency' ? 'bg-rose-500' : 'bg-amber-400'}`}></span>
                        <div className="flex-1">
                          <div className="text-slate-200 font-bold">{alarm.title}</div>
                          <div className="text-[#518b93] text-[9px] mt-0.5">{alarm.time} · {alarm.location}</div>
                        </div>
                        <span className={`px-1.5 py-0.5 rounded text-[8px] border shrink-0 ${
                          alarm.level === 'emergency' ? 'bg-rose-500/20 border-rose-500/40 text-rose-300' : 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                        }`}>{alarm.tag}</span>
                      </div>
                      <div className="flex justify-end border-t border-slate-800/30 pt-1.5 mt-0.5">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setAlarmToProcess(alarm);
                            setSelectedAssignee('李工 (电力运维)');
                            setSelectedPriority('high');
                            setSelectedNotes('');
                          }}
                          className="px-2.5 py-0.5 text-[9px] font-semibold bg-teal-500/20 hover:bg-teal-500/40 border border-teal-500/30 text-teal-300 rounded cursor-pointer transition-all"
                        >
                          处理
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Substation Hierarchy */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center gap-1.5 border-b border-teal-500/10 pb-2 text-xs text-teal-300 font-bold tracking-wider">
                  <Activity className="w-4 h-4 text-teal-400" />
                  <span>配电房分布详情</span>
                </div>

                <div className="flex flex-col gap-3 max-h-[280px] overflow-y-auto pr-1">
                  {cabinetList.map((room, rIdx) => (
                    <div key={rIdx} className="bg-slate-950/30 p-2 rounded-lg border border-slate-800/40">
                      <div className="text-xs font-bold text-teal-400 flex items-center justify-between border-b border-slate-800 pb-1 mb-2">
                        <span>{room.room}</span>
                        <span className="text-[10px] text-slate-500">3台机柜</span>
                      </div>
                      <div className="flex flex-col gap-2">
                        {room.cabs.map((cab, cIdx) => (
                          <div
                            key={cIdx}
                            onClick={() => setSelectedCabinet(cab)}
                            className={`flex items-center justify-between p-2 rounded cursor-pointer transition-colors border ${
                              cab.status === 'fault'
                                ? 'bg-rose-500/10 border-rose-500/20 text-rose-300'
                                : cab.status === 'warning'
                                ? 'bg-amber-500/10 border-amber-500/20 text-amber-300'
                                : 'bg-slate-900/60 border-slate-800/80 text-teal-100 hover:border-slate-600'
                            }`}
                          >
                            <span className="text-xs font-semibold">{cab.name}</span>
                            <span className={`text-[10px] px-1 py-0.5 rounded uppercase ${
                              cab.status === 'fault' ? 'text-rose-400' : cab.status === 'warning' ? 'text-amber-400' : 'text-emerald-400'
                            }`}>{cab.status === 'fault' ? '致命故障' : cab.status === 'warning' ? '超限警告' : '稳定'}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* TAB 3: 能耗分析 Energy Analytics sidebars */}
          {activeTab === 'energy' && (
            <>
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <Activity className="w-4 h-4 text-teal-400" />
                    <span>耗能分析</span>
                  </div>
                  <div className="flex border border-slate-800 p-0.5 rounded text-[9px] bg-slate-950/60 leading-none">
                    <button
                      onClick={() => setEnergyPeriod('today')}
                      className={`py-1 px-1.5 rounded transition-all font-semibold cursor-pointer ${energyPeriod === 'today' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400'}`}
                    >
                      今日
                    </button>
                    <button
                      onClick={() => setEnergyPeriod('month')}
                      className={`py-1 px-1.5 rounded transition-all font-semibold cursor-pointer ${energyPeriod === 'month' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400'}`}
                    >
                      本月
                    </button>
                  </div>
                </div>

                <div className="flex flex-col gap-2">

                  <div className="flex border border-slate-850 p-0.5 rounded-lg bg-slate-950/60 text-[10px] mb-1 leading-none">
                    <button onClick={() => setActiveEnergyView('device')} className={`flex-1 py-1.5 rounded transition-all font-semibold ${activeEnergyView === 'device' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}>按耗能机型</button>
                    <button onClick={() => setActiveEnergyView('stage')} className={`flex-1 py-1.5 rounded transition-all font-semibold ${activeEnergyView === 'stage' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}>按峰谷阶段</button>
                  </div>

                  {activeEnergyView === 'device' ? (
                    <div className="flex flex-col gap-2 bg-slate-950/30 p-2.5 rounded border border-slate-800/40">
                      <div className="flex items-center justify-center py-2">
                        <DonutChart
                          parts={
                            energyPeriod === 'today' ? [
                              { value: 45, color: '#2dd4bf' },
                              { value: 30, color: '#fbbf24' },
                              { value: 15, color: '#a78bfa' },
                              { value: 10, color: '#38bdf8' }
                            ] : [
                              { value: 43, color: '#2dd4bf' },
                              { value: 28, color: '#fbbf24' },
                              { value: 18, color: '#a78bfa' },
                              { value: 11, color: '#38bdf8' }
                            ]
                          }
                          size={90}
                          centerText={energyPeriod === 'today' ? `${totalKwh.toFixed(1)}万` : '98.4万'}
                          centerSubtext="KWh"
                        />
                      </div>
                      {(energyPeriod === 'today' ? [
                        { name: '中央暖通空调系统', pct: 45, val: `${(totalKwh * 0.45).toFixed(2)} 万KWh`, c: 'bg-teal-400' },
                        { name: '照明及展示回路', pct: 30, val: `${(totalKwh * 0.30).toFixed(2)} 万KWh`, c: 'bg-amber-400' },
                        { name: '算力机群及云终端', pct: 15, val: `${(totalKwh * 0.15).toFixed(2)} 万KWh`, c: 'bg-purple-400' },
                        { name: '快慢直流充电站', pct: 10, val: `${(totalKwh * 0.10).toFixed(2)} 万KWh`, c: 'bg-sky-400' }
                      ] : [
                        { name: '中央暖通空调系统', pct: 43, val: '42.31 万KWh', c: 'bg-teal-400' },
                        { name: '照明及展示回路', pct: 28, val: '27.55 万KWh', c: 'bg-amber-400' },
                        { name: '算力机群及云终端', pct: 18, val: '17.71 万KWh', c: 'bg-purple-400' },
                        { name: '快慢直流充电站', pct: 11, val: '10.82 万KWh', c: 'bg-sky-400' }
                      ]).map((dev, idx) => (
                        <div key={idx} className="flex flex-col gap-1 text-[11px] text-slate-300">
                          <div className="flex justify-between items-center font-mono">
                            <span className="flex items-center gap-1.5"><span className={`w-1.5 h-1.5 rounded-full ${dev.c}`} /> {dev.name}</span>
                            <span className="font-bold text-teal-300">{dev.val} ({dev.pct}%)</span>
                          </div>
                          <div className="w-full h-1 bg-slate-900 rounded overflow-hidden">
                            <div className={`h-full ${dev.c}`} style={{ width: `${dev.pct}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col gap-3 text-[11px] bg-slate-950/30 p-2.5 rounded border border-slate-800/40 font-mono">
                      {(energyPeriod === 'today' ? [
                        { label: '尖电能 (10:00~15:00)', pct: 35, val: `${(totalKwh * 0.35).toFixed(2)}万 kWh`, c: 'bg-rose-500' },
                        { label: '峰电能 (08:00~10:00)', pct: 28, val: `${(totalKwh * 0.28).toFixed(2)}万 kWh`, c: 'bg-amber-400' },
                        { label: '平电能 (15:00~22:00)', pct: 22, val: `${(totalKwh * 0.22).toFixed(2)}万 kWh`, c: 'bg-teal-400' },
                        { label: '谷电能 (22:00~08:00)', pct: 15, val: `${(totalKwh * 0.15).toFixed(2)}万 kWh`, c: 'bg-sky-400' }
                      ] : [
                        { label: '尖电能 (10:00~15:00)', pct: 36, val: '35.42万 kWh', c: 'bg-rose-500' },
                        { label: '峰电能 (08:00~10:00)', pct: 27, val: '26.57万 kWh', c: 'bg-amber-400' },
                        { label: '平电能 (15:00~22:00)', pct: 23, val: '22.63万 kWh', c: 'bg-teal-400' },
                        { label: '谷电能 (22:00~08:00)', pct: 14, val: '13.78万 kWh', c: 'bg-sky-400' }
                      ]).map((v, i) => (
                        <div key={i} className="flex flex-col gap-1">
                          <div className="flex justify-between">
                            <span className="text-slate-300">{v.label}</span>
                            <span className="font-bold text-teal-300">{v.val}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex-1 h-2 bg-slate-900 rounded overflow-hidden">
                              <div className={`h-full ${v.c}`} style={{ width: `${v.pct}%` }} />
                            </div>
                            <span className="text-[10px] w-8 text-right font-bold text-slate-400">{v.pct}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Energy anomalies log feed */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center gap-1.5 border-b border-teal-500/10 pb-1.5 text-xs text-teal-300 font-bold">
                  <ShieldAlert className="w-4 h-4 text-teal-400" />
                  <span>能耗异常告警</span>
                </div>
                <div className="flex flex-col gap-2">
                  <div 
                    className="bg-rose-500/5 hover:bg-rose-500/10 border border-rose-500/20 rounded p-2 text-[11px] leading-snug cursor-pointer transition-colors"
                    onClick={() => {
                      setSelectedEnergyAnomaly({
                        event: "20号楼3层 夜间非正常用电",
                        level: "High (高危级能耗突增)",
                        trigger: "超出常规基准值 230%",
                        time: "2026-06-11 02:34:21",
                        location: "科技研发园 20号楼 3层南侧联合办公区",
                        detail: "经三相智能能耗分析仪监测，该支路在夜间非工作时段（02:00～05:00）内总有功功率由 5.2kW 陡升至 17.1kW。波形谱图呈现电感性负载突增特征，高度疑似非授权加热、冷排空调或测试强电设备误运行操作，存在局部电气过温或漏电隐患。",
                        solution: "系统已自动派发缺陷排障工单。建议值班组立即通过‘配电房状态面板’点击对应二级配电柜体执行远程隔离，或联络后勤运维人员前往 20号楼3层 现场排查确认。"
                      });
                      triggerToast("⚡ 已载入 20号楼3层 能耗异常诊断详情");
                    }}
                  >
                    <div className="flex items-center justify-between font-bold text-rose-300">
                      <span>20号楼3层 夜间非正常用电</span>
                      <span className="text-[9px] bg-rose-500/20 border border-rose-500/30 rounded px-1">能耗突增230%</span>
                    </div>
                    <p className="text-slate-400 mt-1">发生在 02:34:21，极有可能是非授权终端运转或强电设备误动作漏电。</p>
                  </div>
                  <div 
                    className="bg-amber-500/5 hover:bg-amber-500/10 border border-amber-500/20 rounded p-2 text-[11px] leading-snug cursor-pointer transition-colors"
                    onClick={() => {
                      setSelectedEnergyAnomaly({
                        event: "A区充电桩 快充回路脉冲异常",
                        level: "Warning (中级畸变波形警告)",
                        trigger: "瞬时谐波含有率 ±45%",
                        time: "2026-06-11 11:15:00",
                        location: "新能源车停车棚 A区 #04快速直流充电回路",
                        detail: "在快充桩大功率输出（120kW）时，互感器采集到强电压波动与高瞬时谐波含有率达到了 45.1%。高频次瞬态脉冲畸变容易加剧配电回路有源整流器（AFE）老化。建议进行电网调谐调峰。",
                        solution: "建议对APF（有源电力滤波器）策略进行谐波补偿整定。在充电峰值段自动切入补偿深度，把回路畸变率抑制在 5% 的国家标准安全范围内。"
                      });
                      triggerToast("⚡ 已载入 A区充电桩 谐波异常波形报告");
                    }}
                  >
                    <div className="flex items-center justify-between font-bold text-amber-300">
                      <span>A区充电桩 快充回路脉冲异常</span>
                      <span className="text-[9px] bg-amber-500/20 border border-amber-500/30 rounded px-1">波动幅度±45%</span>
                    </div>
                    <p className="text-slate-400 mt-1">发生在 11:15，建议下传脉冲抑制阀门调控指令。</p>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* TAB 4: 感知设备巡检 Patrol sidebars */}
          {activeTab === 'patrol' && (
            <>
              {/* Online/Offline Sensor Statistics Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center gap-1.5 border-b border-teal-500/10 pb-2 text-xs text-teal-300 font-bold tracking-wider">
                  <Activity className="w-4 h-4 text-teal-400" />
                  <span>感知设备状态</span>
                </div>

                <div className="bg-slate-950/45 rounded-lg border border-slate-800 overflow-hidden">
                  <table className="w-full text-left text-[11px] font-mono border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 text-[#508890] bg-slate-950/80">
                        <th className="py-2 px-3 font-normal">设备分类</th>
                        <th className="py-2 px-2 text-center font-normal">在线</th>
                        <th className="py-2 px-2 text-center font-normal">异常</th>
                        <th className="py-2 px-2 text-center font-normal">总计</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850">
                      {[
                        { t: '巡天高空监控眼', on: 18, err: 2, n: 20, c: 'bg-teal-400' },
                        { t: '环境无线探测器', on: 42, err: 3, n: 45, c: 'bg-emerald-400' },
                        { t: '陆基步履式机器狗', on: 2, err: 0, n: 2, c: 'bg-amber-400' },
                        { t: '高压通道巡检网', on: 1, err: 0, n: 1, c: 'bg-purple-400' }
                      ].map((row, rIdx) => (
                        <tr key={rIdx} className="hover:bg-teal-500/5">
                          <td className="py-2 px-3 flex items-center gap-1.5 text-slate-200">
                            <span className={`w-1.5 h-1.5 rounded-full ${row.c}`} />
                            <span>{row.t}</span>
                          </td>
                          <td className="py-2 px-2 text-center text-emerald-400 font-bold">{row.on}</td>
                          <td className="py-2 px-2 text-center text-rose-400 font-bold">{row.err}</td>
                          <td className="py-2 px-2 text-center text-slate-400">{row.n}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Inspect metrics by Date record selection Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center gap-1.5 border-b border-teal-500/10 pb-1.5 text-xs text-teal-300 font-bold">
                  <FileText className="w-4 h-4 text-teal-400" />
                  <span>巡检记录</span>
                </div>
                <div className="flex flex-col gap-2">
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-slate-400 font-mono">调阅巡检批次：</span>
                    <select
                      value={activePatrolDate}
                      onChange={(e) => {
                        setActivePatrolDate(e.target.value);
                        triggerToast('已切换调阅巡检数据批次：' + e.target.value);
                      }}
                      className="w-full bg-[#081b24] border border-teal-500/20 text-xs text-slate-200 p-2 rounded outline-none cursor-pointer focus:border-teal-400"
                    >
                      <option value="xj-20260608">常规日间巡检批次 · 06-08 09:00</option>
                      <option value="xj-20260607">例行红外漏磁测描 · 06-07 09:00</option>
                      <option value="xj-20260606">常规雨天巡线批次 · 06-06 09:00</option>
                      <option value="xj-20260605">光伏防雷隔离测试 · 06-05 09:00</option>
                    </select>
                  </div>

                  <div className="bg-slate-950/40 p-1 rounded-lg border border-slate-800/80 max-h-[170px] overflow-y-auto">
                    <table className="w-full text-left text-[10px] font-mono border-collapse">
                      <thead>
                        <tr className="text-[#508890] border-b border-slate-800 bg-slate-950/50">
                          <th className="p-1 px-2 font-normal">测绘项目</th>
                          <th className="p-1 px-2 font-normal">测得数值</th>
                          <th className="p-1 px-2 text-center font-normal">评估</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850/50">
                        {(patrolRecordsMap[activePatrolDate] || patrolRecordsMap['xj-20260608']).map((log, idx) => (
                          <tr key={idx} className="hover:bg-[#071620]">
                            <td className="p-1 px-2 text-slate-300">{log.name}</td>
                            <td className="p-1 px-2 font-bold text-slate-200">{log.value} <span className="text-[8px] text-[#508890] font-normal">{log.unit}</span></td>
                            <td className="p-1 px-2 text-center">
                              <span className={`px-1 rounded-[2px] text-[8px] ${
                                log.status === 'error' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : log.status === 'warning' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              }`}>{log.status === 'error' ? '非正常' : log.status === 'warning' ? '提示' : '正常'}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Quick inspections executive report compile Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center gap-1.5 border-b border-teal-500/10 pb-1.5 text-xs text-teal-300 font-bold">
                  <FileText className="w-4 h-4 text-teal-400" />
                  <span>巡检报告</span>
                </div>
                <div className="flex flex-col gap-1.5">
                  <button
                    onClick={() => setShowReportType('patrol')}
                    className="w-full py-2 bg-gradient-to-r from-teal-950 to-emerald-950 hover:from-teal-900 hover:to-emerald-900 border border-teal-500/30 text-teal-300 rounded font-bold text-xs tracking-wider transition-all flex items-center justify-center gap-2 shadow hover:shadow-teal-500/20 cursor-pointer"
                  >
                    🚀 点击一键拉取生成本批次巡检报告
                  </button>
                </div>
              </div>
            </>
          )}

          {/* TAB 5: 仿真模拟 Simulation parameters sidebars */}
          {activeTab === 'simulate' && (
            <>
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center gap-1.5 border-b border-teal-500/10 pb-2 text-xs text-teal-300 font-bold tracking-wider">
                  <Sliders className="w-4 h-4 text-teal-400" />
                  <span>仿真模拟选择</span>
                </div>

                <div className="flex flex-col gap-1 pb-1">
                  {[
                    { id: 'outage', label: '🔌 停电影响范围模拟' },
                    { id: 'leakage', label: '⚡ 线路漏电与短路模拟' },
                    { id: 'overload', label: '🌡 设备过载异常模拟' }
                  ].map(sim => (
                    <button
                      key={sim.id}
                      onClick={() => {
                        setSimType(sim.id as any);
                        setShowSimResult(false);
                      }}
                      className={`w-full text-left p-2 rounded text-xs transition-colors border ${
                        simType === sim.id 
                          ? 'bg-teal-500/15 border-teal-400/40 text-teal-300 font-bold' 
                          : 'bg-slate-950/30 border-transparent text-[#a3c2ca] hover:bg-slate-900'
                      }`}
                    >
                      {sim.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Simulation params input deck */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center gap-1.5 border-b border-teal-500/10 pb-2 text-xs text-teal-300 font-bold tracking-wider">
                  <Sliders className="w-4 h-4 text-teal-400" />
                  <span>仿真参数调节</span>
                </div>

                <div className="flex flex-col gap-3 text-xs font-mono">
                  <div className="flex flex-col gap-1 text-slate-300">
                    <span>1. 故障发起点:</span>
                    <select
                      value={simTarget}
                      onChange={(e) => setSimTarget(e.target.value)}
                      className="w-full bg-[#081b24] border border-teal-500/20 text-xs text-slate-200 p-2 rounded outline-none"
                    >
                      <option>变压器-T1 (主变回路)</option>
                      <option>配电房-01 (一级主进线)</option>
                      <option>配电房-05 (20#楼分断路器)</option>
                    </select>
                  </div>

                  {simType === 'overload' && (
                    <div className="flex flex-col gap-1.5 text-slate-300">
                      <div className="flex justify-between font-bold">
                        <span>2. 设定过载载荷:</span>
                        <span className="text-teal-400">{simIntensity}% (1.5x)</span>
                      </div>
                      <input
                        type="range"
                        min="100"
                        max="300"
                        value={simIntensity}
                        onChange={(e) => setSimIntensity(+e.target.value)}
                        className="w-full accent-teal-400 cursor-pointer h-1.5 bg-slate-900 rounded-lg outline-none"
                      />
                    </div>
                  )}

                  {simType === 'leakage' && (
                    <div className="flex flex-col gap-1.5 text-slate-300">
                      <div className="flex justify-between font-bold">
                        <span>2. 设定漏电强度:</span>
                        <span className="text-teal-400">{simIntensity} mA</span>
                      </div>
                      <input
                        type="range"
                        min="30"
                        max="500"
                        value={simIntensity}
                        onChange={(e) => setSimIntensity(+e.target.value)}
                        className="w-full accent-teal-400 cursor-pointer h-1.5 bg-slate-900 rounded-lg outline-none"
                      />
                    </div>
                  )}

                  <div className="flex flex-col gap-1.5 text-slate-300">
                    <div className="flex justify-between font-bold">
                      <span>{simType === 'outage' ? '2. 仿真持续时长:' : '3. 仿真持续时长:'}</span>
                      <span className="text-teal-400">{simDuration} min</span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="120"
                      value={simDuration}
                      onChange={(e) => setSimDuration(+e.target.value)}
                      className="w-full accent-teal-400 cursor-pointer h-1.5 bg-slate-900 rounded-lg outline-none"
                    />
                  </div>

                  {/* Simulate control triggers */}
                  <div className="flex gap-2.5 pt-2">
                    <button
                      onClick={handleRunSimulation}
                      disabled={simRunning}
                      className="flex-1 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-slate-950 rounded font-bold transition-all shadow shadow-emerald-500/20 cursor-pointer disabled:opacity-50"
                    >
                      {simRunning ? '仿真计算中...' : '▶ 发起仿真评估'}
                    </button>
                    <button
                      onClick={handleResetSimulation}
                      className="px-3 border border-[#1a4a5e] bg-slate-950/40 text-slate-300 rounded hover:bg-slate-900 cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Simulation Result placards */}
              {showSimResult && (
                <div className="bg-[#120406]/90 border border-rose-500/35 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#150508]/95 hover:border-rose-400/45 transition-all flex flex-col gap-3 shrink-0 text-xs leading-normal animate-scale-up">
                  <div className="flex items-center gap-1.5 text-rose-400 font-bold border-b border-rose-500/20 pb-1.5 uppercase">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>仿真结果报告 - {simulationDetails[simType].title}</span>
                  </div>
                  <div className="flex flex-col gap-2 font-mono text-[11px] mt-1 text-left">
                    {simulationDetails[simType].results.map((res: any, idx: number) => (
                      <div key={idx} className="flex flex-col gap-0.5">
                        <span className="text-slate-400">{res.label}:</span>
                        <span className={`font-bold ${res.color}`}>{res.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {/* TAB 6: 巡检任务与工单运维 Operations and Support sidebars */}
          {activeTab === 'ops' && (
            <>
              {/* Card 1: 运维概览 */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <Activity className="w-4 h-4 text-teal-400" />
                    <span>运维概览</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="bg-slate-950/40 p-2 border border-slate-800/40 rounded text-left">
                    <span className="text-[10px] text-slate-400 block font-medium">待处理工单</span>
                    <span className="text-sm font-bold text-teal-400 mt-1 block">
                      {workOrders.filter(w => w.status === 'pending').length} 件
                    </span>
                  </div>
                  <div className="bg-slate-950/40 p-2 border border-slate-800/40 rounded text-left">
                    <span className="text-[10px] text-amber-500 block font-medium">进行中工单</span>
                    <span className="text-sm font-bold text-amber-400 mt-1 block">
                      {workOrders.filter(w => w.status === 'processing').length} 件
                    </span>
                  </div>
                  <div className="bg-slate-950/40 p-2 border border-slate-800/40 rounded text-left">
                    <span className="text-[10px] text-emerald-400 block font-medium">今日完成</span>
                    <span className="text-sm font-bold text-emerald-400 mt-1 block">
                      {workOrders.filter(w => w.status === 'completed').length + 8} 件
                    </span>
                  </div>
                  <div className="bg-slate-950/40 p-2 border border-slate-800/40 rounded text-left">
                    <span className="text-[10px] text-indigo-400 block font-medium">综合完成率</span>
                    <span className="text-sm font-bold text-indigo-300 mt-1 block">
                      {((workOrders.filter(w => w.status === 'completed').length + 8) / (workOrders.length + 8) * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Card 2: 告警统计分级 */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-[#143d4c] pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <ShieldAlert className="w-4 h-4 text-teal-400" />
                    <span>告警统计分级</span>
                  </div>
                  <div className="flex border border-slate-800 p-0.5 rounded text-[9px] bg-slate-950/60 leading-none">
                    <button
                      onClick={() => setAlarmStatPeriod('today')}
                      className={`py-1 px-1.5 rounded transition-all font-semibold cursor-pointer ${alarmStatPeriod === 'today' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400'}`}
                    >
                      今日
                    </button>
                    <button
                      onClick={() => setAlarmStatPeriod('week')}
                      className={`py-1 px-1.5 rounded transition-all font-semibold cursor-pointer ${alarmStatPeriod === 'week' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400'}`}
                    >
                      本周
                    </button>
                    <button
                      onClick={() => setAlarmStatPeriod('month')}
                      className={`py-1 px-1.5 rounded transition-all font-semibold cursor-pointer ${alarmStatPeriod === 'month' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400'}`}
                    >
                      本月
                    </button>
                  </div>
                </div>

                <div className="flex flex-col gap-2 font-mono text-[11px] leading-snug">
                  {[
                    { 
                      label: '🚨 致命紧急告警', 
                      val: alarmStatPeriod === 'today' ? 4 : alarmStatPeriod === 'week' ? 18 : 52, 
                      color: 'text-rose-400', 
                      bar: 'bg-rose-500', 
                      pct: alarmStatPeriod === 'today' ? 30 : alarmStatPeriod === 'week' ? 40 : 45 
                    },
                    { 
                      label: '⚠ 严重故障告警', 
                      val: alarmStatPeriod === 'today' ? 6 : alarmStatPeriod === 'week' ? 24 : 78, 
                      color: 'text-amber-400', 
                      bar: 'bg-amber-500', 
                      pct: alarmStatPeriod === 'today' ? 50 : alarmStatPeriod === 'week' ? 55 : 65 
                    },
                    { 
                      label: 'ℹ 一般提示警告', 
                      val: alarmStatPeriod === 'today' ? 4 : alarmStatPeriod === 'week' ? 15 : 45, 
                      color: 'text-teal-400', 
                      bar: 'bg-teal-500', 
                      pct: alarmStatPeriod === 'today' ? 20 : alarmStatPeriod === 'week' ? 25 : 30 
                    }
                  ].map((stat, idx) => (
                    <div key={idx} className="flex flex-col gap-1 text-left bg-slate-950/30 p-2 rounded border border-slate-800/40">
                      <div className="flex justify-between items-center font-bold">
                        <span className={stat.color}>{stat.label}</span>
                        <span className="text-slate-200">{stat.val} 次</span>
                      </div>
                      <div className="w-full h-1 bg-slate-900 rounded overflow-hidden mt-1">
                        <div className={`h-full ${stat.bar}`} style={{ width: `${stat.pct}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card 3: 任务工单 (Moved from Right Sidebar) */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-[#143d4c] pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <Wrench className="w-4 h-4 text-teal-400" />
                    <span>任务工单</span>
                  </div>
                  <button
                    onClick={() => {
                      const newOrder: WorkOrder = {
                        id: `WO-2026-${Math.floor(100 + Math.random() * 900)}`,
                        title: '配电房继电保护极性校验参数校订',
                        type: 'upgrade',
                        status: 'pending',
                        assignee: '王技术主管',
                        time: '14:30'
                      };
                      setWorkOrders([newOrder, ...workOrders]);
                      triggerToast('已成功创建电气校验升级工单并通知分配王技术主管！');
                    }}
                    className="text-[9px] bg-teal-500/20 hover:bg-teal-500/40 border border-teal-500/30 text-teal-300 px-1.5 py-0.5 rounded cursor-pointer transition-all"
                  >
                    + 新建工单
                  </button>
                </div>

                <div className="flex flex-col gap-2 max-h-[190px] overflow-y-auto pr-1">
                  {workOrders.map((order, idx) => (
                    <div key={idx} className="bg-slate-950/40 p-2 rounded border border-slate-850/50 text-left text-xs font-mono">
                      <div className="flex items-center justify-between mb-1.5 font-bold leading-none">
                        <span className="text-slate-200 truncate max-w-[150px]">{order.title}</span>
                        <span className={`px-1 rounded text-[8px] border shrink-0 ${
                          order.status === 'completed' 
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' 
                            : order.status === 'processing' 
                            ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' 
                            : 'bg-slate-800 border-slate-700 text-slate-400'
                        }`}>{order.status === 'completed' ? '已完成' : order.status === 'processing' ? '处理中' : '待处理'}</span>
                      </div>
                      <div className="flex justify-between items-center text-[10px] text-slate-400">
                        <span>工单编号: {order.id}</span>
                        <span>{order.assignee} · {order.time}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </aside>

        {/* ----------------- RIGHT SIDEBAR TELEMETRY PANEL (Frosted Glassmorphism Overlay) ----------------- */}
        <aside className="absolute right-4 top-4 bottom-4 w-[310px] hidden md:flex flex-col gap-4 overflow-y-auto z-20 pointer-events-auto shrink-0 select-none custom-scrollbar p-0 bg-transparent border-0 shadow-none backdrop-blur-none pb-4">
          
          {/* TAB 1: 首页 (Home widgets right side) */}
          {activeTab === 'home' && (
            <>
              {/* 实时告警 (Real-time Alarms Panel) - Frosted Glass Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center gap-1.5 border-b border-teal-500/10 pb-2 text-xs text-rose-400 font-bold tracking-wider">
                  <AlertTriangle className="w-4 h-4 text-rose-400 animate-pulse" />
                  <span>实时告警</span>
                </div>
                <div className="flex flex-col gap-2 max-h-[140px] overflow-y-auto custom-scrollbar pr-1">
                  {[
                    { id: 'home-al-1', title: '配电柜 2-C3 运行温度异常偏高', time: '10:14', location: '1号配电房', level: 'emergency', tag: '高危告警' },
                    { id: 'home-al-2', title: '智能球机 C4 西北视角网络离线', time: '09:45', location: '外墙西侧网格外围', level: 'warning', tag: '摄像头离线' },
                    { id: 'home-al-3', title: '巡航无人机 D2 主控阻值瞬时偏高', time: '08:24', location: '高空立体巡界网', level: 'warning', tag: '设备受阻' }
                  ].map(alarm => (
                    <div key={alarm.id} className="flex gap-2 text-left bg-slate-950/40 p-2 rounded border border-slate-800/60 text-[11px] leading-tight">
                      <span className={`w-1.5 h-1.5 rounded-full mt-1 shrink-0 ${alarm.level === 'emergency' ? 'bg-rose-500' : 'bg-amber-400'}`}></span>
                      <div className="flex-1">
                        <div className="text-slate-200 font-bold">{alarm.title}</div>
                        <div className="text-[#518b93] text-[9px] mt-0.5">{alarm.time} · {alarm.location}</div>
                      </div>
                      <span className={`px-1.5 py-0.5 rounded text-[8px] border shrink-0 ${
                        alarm.level === 'emergency' ? 'bg-rose-500/20 border-rose-500/40 text-rose-300' : 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                      }`}>{alarm.tag}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 天气与环境情况面板 - Dedicated Frosted Glass Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-1.5">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    {activeSubChart === 'weather' ? <Sun className="w-4 h-4 text-amber-400 animate-pulse" /> : <Activity className="w-4 h-4 text-cyan-400" />}
                    <span>{activeSubChart === 'weather' ? '气象环境监测' : activeSubChart === 'water' ? '积水防汛监测' : '温控环境状态'}</span>
                  </div>
                </div>
                {activeSubChart === 'weather' ? (
                  <div className="bg-slate-950/30 border border-slate-850 p-2.5 rounded-lg flex flex-col gap-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Sun className="w-8 h-8 text-amber-400 animate-pulse" />
                        <div>
                          <div className="text-xs font-bold text-slate-100 flex items-center gap-1">
                            晴转多云 <span className="text-teal-400">26°C</span>
                          </div>
                          <div className="text-[9px] text-[#518b93] font-mono">当日预测: 20°C ~ 31°C</div>
                        </div>
                      </div>
                      <div className="text-right text-[9px] text-[#81a9b3] leading-tight font-mono">
                        <div>常州市新北区</div>
                        <div className="text-emerald-400 mt-0.5">🍃 空气质量: 18 优</div>
                      </div>
                    </div>
                    {/* Grid stats */}
                    <div className="grid grid-cols-3 gap-1.5 text-[9px] text-slate-300 font-mono text-center">
                      <div className="bg-slate-900/60 p-1.5 rounded border border-slate-800/40">
                        <span className="text-[#518b93] block mb-0.5 scale-90">相对湿度</span>
                        <span className="font-bold text-teal-300">52 %</span>
                      </div>
                      <div className="bg-slate-900/60 p-1.5 rounded border border-slate-800/40">
                        <span className="text-[#518b93] block mb-0.5 scale-90">东南风向</span>
                        <span className="font-bold text-teal-300">3-4级</span>
                      </div>
                      <div className="bg-slate-900/60 p-1.5 rounded border border-slate-800/40">
                        <span className="text-[#518b93] block mb-0.5 scale-90">紫外线指数</span>
                        <span className="font-bold text-teal-300">弱</span>
                      </div>
                    </div>
                    {/* Hourly Sunlight Trend */}
                    <div className="border-t border-slate-800 pt-2">
                      <div className="text-[8px] text-[#518b93] mb-1 font-mono uppercase">日照辐射强度趋势 (W/㎡)</div>
                      <MultiLineChart data={getSubChartData()} width={246} height={50} xLabels={['2h', '6h', '10h', '14h', '18h', '22h']} />
                    </div>
                  </div>
                ) : activeSubChart === 'water' ? (
                  <div className="bg-slate-950/30 border border-slate-850 p-2.5 rounded-lg flex flex-col gap-2 flex-grow animate-fade-in">
                    <div className="flex justify-between items-center bg-slate-900/40 p-2 rounded border border-slate-800/30 text-[10px] leading-tight">
                      <span className="text-slate-300">🌊 园区平均积水深度: <span className="font-mono text-cyan-400 font-bold">1.22 m</span></span>
                      <span className="text-[9px] border border-emerald-500/20 bg-emerald-950/20 px-1.5 py-0.5 text-emerald-400 rounded leading-none">水位正常</span>
                    </div>
                    <div>
                      <div className="text-[8px] text-[#518b93] mb-1 font-mono uppercase">当日水位变化走势监测 (m)</div>
                      <MultiLineChart data={getSubChartData()} width={246} height={60} xLabels={['2h', '6h', '10h', '14h', '18h', '22h']} />
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-950/20 border border-slate-850 p-1 rounded-lg animate-fade-in">
                    <MultiLineChart data={getSubChartData()} width={246} height={90} xLabels={['2h', '6h', '10h', '14h', '18h', '22h']} />
                  </div>
                )}
              </div>

              {/* 人流车流分析 (Pedestrian/Vehicle Occupancy Multi Bar charting) - Frosted Glass Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-1.5">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <BarChart3 className="w-4 h-4 text-teal-400" />
                    <span>人流车流分析</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[10px] font-mono leading-none">
                  <div className="bg-slate-950/40 p-2 rounded-lg border border-slate-850/50">
                    <span className="text-slate-400 font-sans">今日人流:</span>
                    <div className="text-sm font-bold text-teal-400 mt-1">2,847 人次</div>
                  </div>
                  <div className="bg-slate-950/40 p-2 rounded-lg border border-slate-850/50">
                    <span className="text-slate-400 font-sans">今日车流:</span>
                    <div className="text-sm font-bold text-purple-400 mt-1">683 辆次</div>
                  </div>
                </div>

                {/* 车位实时数据 */}
                <div className="bg-slate-950/40 border border-slate-850/55 p-2 rounded-lg flex flex-col gap-1.5 text-[10px] font-mono">
                  <div className="flex items-center justify-between text-slate-300 font-sans">
                    <span className="font-bold flex items-center gap-1">🚙 实时车位工况</span>
                    <span className="text-[9px] text-[#2dd4bf] font-mono">实时更新</span>
                  </div>
                  <div className="grid grid-cols-3 gap-1.5 text-center mt-0.5 leading-none">
                    <div className="bg-[#122c3a]/30 p-1.5 rounded border border-teal-500/15">
                      <div className="text-[9px] text-[#518b93] font-sans scale-90">车位总数</div>
                      <div className="text-xs font-bold text-teal-300 mt-1">150</div>
                    </div>
                    <div className="bg-[#1c1214]/60 p-1.5 rounded border border-rose-500/15">
                      <div className="text-[9px] text-[#8c676d] font-sans scale-90">已占用</div>
                      <div className="text-xs font-bold text-rose-300 mt-1">112</div>
                    </div>
                    <div className="bg-[#11231f]/60 p-1.5 rounded border border-emerald-500/15">
                      <div className="text-[9px] text-[#518276] font-sans scale-90">空闲车位</div>
                      <div className="text-xs font-bold text-[#34d399] mt-1">38</div>
                    </div>
                  </div>
                </div>
                <div className="bg-slate-900/20 border border-slate-850 p-1.5 rounded-lg">
                  <BarChart
                    valuesA={[80, 150, 310, 420, 350, 260, 220, 290]}
                    valuesB={[20, 45, 110, 140, 100, 75, 85, 105]}
                    width={246}
                    height={70}
                    labels={['08h', '10h', '12h', '14h', '16h', '18h', '20h', '22h']}
                    maxVal={500}
                  />
                  <div className="flex justify-center gap-3 text-[8px] font-medium text-slate-400 mt-1">
                    <span className="flex items-center gap-1 font-sans"><span className="w-1.5 h-1.5 bg-teal-400 rounded-sm"></span>闸口人流量</span>
                    <span className="flex items-center gap-1 font-sans"><span className="w-1.5 h-1.5 bg-purple-400 rounded-sm"></span>卡口车流量</span>
                  </div>
                </div>
              </div>
            </>
          )}


          {/* TAB 2: 配电房 Subsystem detailed charts (Right Panel) */}
          {activeTab === 'distribution' && (
            <>
              {/* Cabinet status metrics - Frosted Glass Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <Activity className="w-4 h-4 text-teal-400" />
                    <span>配电柜运行监测</span>
                  </div>
                  <div className="flex border border-slate-800 p-0.5 rounded text-[9px] bg-slate-950/60 leading-none">
                    <button 
                      onClick={() => {
                        setCabMonitorTab('today');
                        triggerToast('已切换至今日配电柜运行监测数据');
                      }} 
                      className={`py-1 px-2 rounded transition-all font-semibold cursor-pointer ${cabMonitorTab === 'today' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      今日
                    </button>
                    <button 
                      onClick={() => {
                        setCabMonitorTab('month');
                        triggerToast('已切换至本月配电柜运行监测数据');
                      }} 
                      className={`py-1 px-2 rounded transition-all font-semibold cursor-pointer ${cabMonitorTab === 'month' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      本月
                    </button>
                  </div>
                </div>

                <div className="bg-slate-950/20 border border-slate-850 p-1.5 rounded-lg">
                  <MultiLineChart
                    data={cabMonitorTab === 'today' ? [
                      { name: '正常柜', points: [31, 31, 32, 29, 31, 31, 32, 33, 31, 31, 32, 31], color: '#34d399' },
                      { name: '告警柜', points: [1, 2, 1, 3, 2, 4, 3, 2, 1, 2, 3, 1], color: '#fbbf24' }
                    ] : [
                      { name: '正常柜', points: [28, 29, 31, 30, 32, 31, 30, 32, 31, 33, 31, 32], color: '#34d399' },
                      { name: '告警柜', points: [4, 3, 2, 3, 1, 2, 3, 1, 2, 1, 2, 1], color: '#fbbf24' }
                    ]}
                    xLabels={cabMonitorTab === 'today' ? ['2h', '4h', '6h', '8h', '10h', '12h'] : ['5日', '10日', '15日', '20日', '25日', '30日']}
                  />
                  <div className="flex justify-center gap-3 text-[8px] font-medium text-[#508890] mt-1.5">
                    <span className="flex items-center gap-1 font-sans"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> 正常柜占比: {cabMonitorTab === 'today' ? '92%' : '86%'}</span>
                    <span className="flex items-center gap-1 font-sans"><span className="w-1.5 h-1.5 rounded-full bg-amber-400" /> 警示柜占比: {cabMonitorTab === 'today' ? '5%' : '8%'}</span>
                  </div>
                </div>
              </div>

              {/* Feed lines dynamic occupancy gauges - Frosted Glass Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0 text-xs">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold">
                    <Activity className="w-4 h-4 text-teal-400" />
                    <span>线路负载率</span>
                  </div>
                </div>

                <div className="flex flex-col gap-3 bg-slate-950/20 p-2.5 rounded border border-slate-850/50 font-mono">
                  {[
                    { name: '10kV 环网联络主干线 A', pct: 72, c: 'bg-emerald-500' },
                    { name: '10kV 环网主干互备线 B', pct: 88, c: 'bg-amber-500 text-amber-300' },
                    { name: '20#楼算力数据中心分支 C1', pct: 106, c: 'bg-rose-500 text-rose-300 animate-pulse' },
                    { name: '16#研发试验基地分支 C2', pct: 65, c: 'bg-emerald-500' },
                    { name: '18#综合动力配套分支 D1', pct: 45, c: 'bg-emerald-500' }
                  ].map((line, idx) => (
                    <div key={idx} className="flex flex-col gap-1 text-[11px]">
                      <div className="flex justify-between items-center text-slate-300 font-semibold leading-none">
                        <span>{line.name}</span>
                        <span className={`font-bold ${line.pct > 100 ? 'text-rose-400' : 'text-teal-300'}`}>{line.pct}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${line.c}`} style={{ width: `${Math.min(line.pct, 100)}%` }} />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2 text-[8px] font-medium text-slate-400 px-1">
                  <span className="flex items-center gap-1"><span className="w-2 h-1.5 bg-emerald-500 rounded-sm" /> &lt;80% 正常容裕</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-1.5 bg-amber-500 rounded-sm" /> 80-100% 重载</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-1.5 bg-rose-500 rounded-sm" /> &gt;100% 越限跳闸警告</span>
                </div>
              </div>
            </>
          )}

          {/* TAB 3: 能耗分析 Energy metrics ranking & green stats */}
          {activeTab === 'energy' && (
            <>
              {/* Leaderboards - Frosted Glass Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <BarChart3 className="w-4 h-4 text-teal-400" />
                    <span>耗能排名</span>
                  </div>
                  <div className="flex border border-slate-800 p-0.5 rounded text-[9px] bg-slate-950/60 leading-none">
                    <button onClick={() => setActiveEnergyRank('enterprise')} className={`py-1 px-1.5 rounded transition-all font-semibold ${activeEnergyRank === 'enterprise' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400'}`}>企业</button>
                    <button onClick={() => setActiveEnergyRank('building')} className={`py-1 px-1.5 rounded transition-all font-semibold ${activeEnergyRank === 'building' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400'}`}>楼宇</button>
                  </div>
                </div>

                <div className="flex flex-col gap-2 max-h-[220px] overflow-y-auto pr-1 select-none font-mono text-[11px] leading-none">
                  {activeEnergyRank === 'enterprise' ? (
                    [
                      { r: 1, name: 'AI算力中心机房', val: '4,820 kWh', trend: '↑12%', c: 'text-rose-400', pct: 100 },
                      { r: 2, name: '智联芯片科技分部', val: '3,660 kWh', trend: '↓3%', c: 'text-emerald-400', pct: 76 },
                      { r: 3, name: '云宇协同渲染工坊', val: '2,990 kWh', trend: '↑5%', c: 'text-rose-400', pct: 62 },
                      { r: 4, name: '数字高频无线研究所', val: '2,460 kWh', trend: '↓8%', c: 'text-emerald-400', pct: 51 },
                      { r: 5, name: '绿能低碳技术转化实验室', val: '1,830 kWh', trend: '↑2%', c: 'text-rose-400', pct: 38 }
                    ].map(ent => (
                      <div key={ent.r} className="flex items-center gap-2.5 bg-slate-950/30 p-2 rounded border border-slate-850/50">
                        <span className="w-4 h-4 rounded bg-slate-905 border border-teal-500/10 text-teal-400 flex items-center justify-center font-bold text-[10px]">{ent.r}</span>
                        <div className="flex-1 flex flex-col gap-1 text-[11px]">
                          <div className="flex justify-between font-bold text-slate-300">
                            <span>{ent.name}</span>
                            <span>{ent.val}</span>
                          </div>
                          <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-teal-980 to-teal-400 rounded-full" style={{ width: `${ent.pct}%` }} />
                          </div>
                        </div>
                        <span className={`text-[9px] font-bold ${ent.c}`}>{ent.trend}</span>
                      </div>
                    ))
                  ) : (
                    [
                      { r: 1, name: '20号楼（综合大厦）', val: '8,640 kWh', pct: 100 },
                      { r: 2, name: '18号楼（智能硬件厂区）', val: '6,400 kWh', pct: 74 },
                      { r: 3, name: '16号楼（低碳办公基地）', val: '5,010 kWh', pct: 58 },
                      { r: 4, name: '12号楼（配套食堂及动力站）', val: '3,890 kWh', pct: 45 },
                      { r: 5, name: '10号楼（孵化器基地）', val: '2,850 kWh', pct: 33 }
                    ].map(bld => (
                      <div key={bld.r} className="flex items-center gap-2 bg-slate-950/30 p-2 rounded border border-slate-850/50">
                        <span className="w-5 h-5 rounded bg-slate-950 border border-teal-500/10 text-teal-400 flex items-center justify-center font-bold text-[10px]">{bld.r}</span>
                        <div className="flex-1 flex flex-col gap-1.5">
                          <div className="flex justify-between font-bold text-slate-300">
                            <span>{bld.name}</span>
                            <span>{bld.val}</span>
                          </div>
                          <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-teal-980 to-teal-400 rounded-full" style={{ width: `${bld.pct}%` }} />
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Green Solar / Carbon Offset calculations - Frosted Glass Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold">
                    <Activity className="w-4 h-4 text-teal-400" />
                    <span>绿电分析</span>
                  </div>
                  {/* 今日 / 本月 Tab Switcher */}
                  <div className="flex border border-slate-800 p-0.5 rounded text-[9px] bg-slate-950/60 leading-none">
                    <button 
                      onClick={() => setGreenAnalysisPeriod('today')}
                      className={`py-1 px-2 rounded-md transition-all font-semibold cursor-pointer ${greenAnalysisPeriod === 'today' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      今日
                    </button>
                    <button 
                      onClick={() => setGreenAnalysisPeriod('month')}
                      className={`py-1 px-2 rounded-md transition-all font-semibold cursor-pointer ${greenAnalysisPeriod === 'month' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      本月
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px] font-mono leading-tight">
                  <div className="bg-slate-950/40 p-2 rounded border border-slate-850/40 text-left">
                    <span className="text-slate-400 font-sans">{greenAnalysisPeriod === 'today' ? '光伏本日发电:' : '光伏本月发电:'}</span>
                    <div className="text-sm font-bold text-emerald-400 mt-1">{greenAnalysisPeriod === 'today' ? '6,400 kWh' : '18.2 万 kWh'}</div>
                  </div>
                  <div className="bg-slate-950/40 p-2 rounded border border-slate-850/40 text-left">
                    <span className="text-slate-400 font-sans">{greenAnalysisPeriod === 'today' ? '储能本日蓄电:' : '储能本月蓄电:'}</span>
                    <div className="text-sm font-bold text-teal-400 mt-1">{greenAnalysisPeriod === 'today' ? '2,100 kWh' : '5.8 万 kWh'}</div>
                  </div>
                  <div className="bg-slate-950/40 p-2 rounded border border-slate-850/40 text-left">
                    <span className="text-slate-400 font-sans">并网绿电消耗:</span>
                    <div className="text-sm font-bold text-amber-400 mt-1">{greenAnalysisPeriod === 'today' ? '4,300 kWh' : '12.4 万 kWh'}</div>
                  </div>
                  <div className="bg-slate-950/40 p-2 rounded border border-slate-850/40 text-left">
                    <span className="text-slate-400 font-sans">{greenAnalysisPeriod === 'today' ? '本日碳排减免:' : '本月碳排减免:'}</span>
                    <div className="text-sm font-bold text-emerald-400 mt-1">{greenAnalysisPeriod === 'today' ? '3.2 吨 CO₂' : '92.5 吨 CO₂'}</div>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* TAB 4: 感知设备巡检 Cameras & thermal capture charts */}
          {activeTab === 'patrol' && (
            <>
              {/* Card 1: 巡检视频监控 (Only one video screen, dropdown select per type) - Frosted Glass Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <Video className="w-4 h-4 text-teal-400" />
                    <span>巡检监控画面</span>
                  </div>
                  {/* Category switcher */}
                  <div className="flex border border-slate-800 p-0.5 rounded text-[9px] bg-slate-950/60 leading-none">
                    <button 
                      onClick={() => {
                        setPatrolVideoTab('video');
                        setSelectedPatrolVideo('cam1');
                        triggerToast('已选择 监控视频 设备列表');
                      }} 
                      className={`py-1 px-1.5 rounded transition-all font-semibold cursor-pointer ${patrolVideoTab === 'video' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      监控
                    </button>
                    <button 
                      onClick={() => {
                        setPatrolVideoTab('drone');
                        setSelectedPatrolVideo('drone1');
                        triggerToast('已选择 无人机 视频源列表');
                      }} 
                      className={`py-1 px-1.5 rounded transition-all font-semibold cursor-pointer ${patrolVideoTab === 'drone' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      无人机
                    </button>
                    <button 
                      onClick={() => {
                        setPatrolVideoTab('dog');
                        setSelectedPatrolVideo('dog1');
                        triggerToast('已选择 机器狗 视频检测点位列表');
                      }} 
                      className={`py-1 px-1.5 rounded transition-all font-semibold cursor-pointer ${patrolVideoTab === 'dog' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      机器狗
                    </button>
                  </div>
                </div>

                {/* Dropdown list selection for the selected category */}
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] text-slate-400 text-left font-sans font-medium">选择视频源：</span>
                  <select
                    value={selectedPatrolVideo}
                    onChange={(e) => {
                      setSelectedPatrolVideo(e.target.value);
                      const feedName = (
                        patrolVideoTab === 'video' ? [
                          { id: 'cam1', name: '01·主进线回路' },
                          { id: 'cam2', name: '02·电容器防火舱' },
                          { id: 'cam3', name: '03·户外母线桥' },
                          { id: 'cam4', name: '07·高空球型机' }
                        ] : patrolVideoTab === 'drone' ? [
                          { id: 'drone1', name: 'UAV-01·光伏组板扫频' },
                          { id: 'drone2', name: 'UAV-02·逆变器组红外' },
                          { id: 'drone3', name: 'UAV-03·高压架电缆扫' },
                          { id: 'drone4', name: 'UAV-04·立体气压传感器' }
                        ] : [
                          { id: 'dog1', name: 'DOG-01·电容器局放仪' },
                          { id: 'dog2', name: 'DOG-02·防水壁漫流探' },
                          { id: 'dog3', name: 'DOG-03·母接地排气扫描' },
                          { id: 'dog4', name: 'DOG-04·高阶红外局放表' } ]
                      ).find(v => v.id === e.target.value)?.name || '';
                      triggerToast(`已切换当前视频画面为：${feedName}`);
                    }}
                    className="w-full bg-[#081b24] border border-teal-500/20 text-xs text-slate-200 p-2 rounded outline-none cursor-pointer focus:border-teal-400"
                  >
                    {patrolVideoTab === 'video' ? (
                      <>
                        <option value="cam1">01·主进线回路实时流信息</option>
                        <option value="cam2">02·电容器防火舱多维热成像</option>
                        <option value="cam3">03·户外母线桥高灵敏微变流</option>
                        <option value="cam4">07·高空球型机高倍云台变焦</option>
                      </>
                    ) : patrolVideoTab === 'drone' ? (
                      <>
                        <option value="drone1">UAV-01·光伏组板密集扫射探测</option>
                        <option value="drone2">UAV-02·逆变器汇流高精度红外</option>
                        <option value="drone3">UAV-03·跨距高压架架空主缆扫描</option>
                        <option value="drone4">UAV-04·多维立体微气候气压探流</option>
                      </>
                    ) : (
                      <>
                        <option value="dog1">DOG-01·底盘电容器微波局放感测</option>
                        <option value="dog2">DOG-02·地面防涝漫流渗水检测</option>
                        <option value="dog3">DOG-03·主变抗震接地排腐蚀红外</option>
                        <option value="dog4">DOG-04·二次集污箱阀泄偏水位计照</option>
                      </>
                    )}
                  </select>
                </div>

                {/* Display Single Video Feed Screen */}
                {(() => {
                  const currentFeed = (
                    patrolVideoTab === 'video' ? [
                      { id: 'cam1', name: '01·主进线回路', ok: true },
                      { id: 'cam2', name: '02·电容器防火舱', ok: true },
                      { id: 'cam3', name: '03·户外母线桥', ok: true },
                      { id: 'cam4', name: '07·高空球型机', ok: false }
                    ] : patrolVideoTab === 'drone' ? [
                      { id: 'drone1', name: 'UAV-01·光伏组板扫频', ok: true },
                      { id: 'drone2', name: 'UAV-02·逆变器组红外', ok: true },
                      { id: 'drone3', name: 'UAV-03·高压架电缆扫', ok: true },
                      { id: 'drone4', name: 'UAV-04·立体气压传感器', ok: true }
                    ] : [
                      { id: 'dog1', name: 'DOG-01·电容器局放仪', ok: true },
                      { id: 'dog2', name: 'DOG-02·防水壁漫流探', ok: true },
                      { id: 'dog3', name: 'DOG-03·母接地排气扫描', ok: true },
                      { id: 'dog4', name: 'DOG-04·高阶红外局放表', ok: true }
                    ]
                  ).find(v => v.id === selectedPatrolVideo) || { id: 'cam1', name: '01·主进线回路', ok: true };

                  return (
                    <div className="relative aspect-video bg-black/95 rounded-lg border border-teal-500/25 overflow-hidden flex flex-col justify-between p-2.5 shadow-inner">
                      {currentFeed.ok ? (
                        <>
                          {/* Animated Scan Line and radar sweeping pattern */}
                          <div className="absolute inset-0 bg-transparent pointer-events-none overflow-hidden">
                            <div className="w-full h-[1.5px] bg-teal-500/30 absolute shadow-[0_0_8px_rgba(45,212,191,0.5)] animate-pulse" />
                            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(45,212,191,0.06)_0%,rgba(0,0,0,0)_80%)]" />
                          </div>

                          {/* Signal Telemetry Label */}
                          <div className="absolute top-2 left-2 flex flex-col items-start font-mono text-[8.5px] text-teal-400/85 leading-tight">
                            <span>RESOL: 1920x1080 @ 30FPS</span>
                            <span>BITRATE: {(4.2).toFixed(1)} Mbps</span>
                            <span>LATENCY &lt; 20ms SYSTEM OK</span>
                          </div>

                          {/* PULSING LIVE REC Indicator */}
                          <div className="absolute top-2 right-2 flex items-center gap-1.5 text-[9px] bg-red-650/40 text-red-400 border border-red-500/35 px-1.5 py-0.5 rounded leading-none shrink-0 font-mono font-black animate-pulse">
                            <span className="w-1.5 h-1.5 bg-red-400 rounded-full" />
                            <span>LIVE REC</span>
                          </div>

                          {/* Center Scope Sight Crosshairs */}
                          <div className="absolute inset-0 flex items-center justify-center opacity-30 pointer-events-none">
                            <div className="w-6 h-[1px] bg-teal-400" />
                            <div className="h-6 w-[1px] bg-teal-400" />
                            <div className="w-10 h-10 border border-teal-400 rounded-full" />
                          </div>

                          <div /> {/* Spacer */}

                          {/* Display name at the bottom in tech bar */}
                          <div className="relative z-10 flex justify-between items-center text-[10px] text-white bg-slate-950/80 p-1 px-2 rounded border border-teal-500/20 font-mono">
                            <span className="text-teal-300 font-bold truncate">{currentFeed.name}</span>
                            <span className="text-[8.5px] text-emerald-400">CONNECTING...</span>
                          </div>
                        </>
                      ) : (
                        <div className="absolute inset-0 flex flex-col items-center justify-center font-mono bg-slate-950 p-4">
                          <AlertTriangle className="w-7 h-7 text-rose-500 animate-bounce mb-2" />
                          <span className="text-[10px] text-rose-400 font-bold tracking-wider">该点位网络信号离线 (DVC LOST)</span>
                          <span className="text-[8px] text-slate-500 mt-1 uppercase">NO RECON LINK CONNECT RESCUE...</span>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>

              {/* Dynamic instrument capture snapshot deck - Frosted Glass Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold">
                    <Video className="w-4 h-4 text-teal-400" />
                    <span>巡检抓拍</span>
                  </div>
                  {/* Tab switchers: 监控视频, 无人机, 机器狗 */}
                  <div className="flex border border-slate-800 p-0.5 rounded text-[9px] bg-slate-950/60 leading-none">
                    <button 
                      onClick={() => {
                        setPatrolCaptureTab('video');
                        triggerToast('已切换至【监控视频】测温抓拍照');
                      }} 
                      className={`py-1 px-1 rounded transition-all font-semibold cursor-pointer ${patrolCaptureTab === 'video' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      监控
                    </button>
                    <button 
                      onClick={() => {
                        setPatrolCaptureTab('drone');
                        triggerToast('已切换至【无人机】高空热像照');
                      }} 
                      className={`py-1 px-1 rounded transition-all font-semibold cursor-pointer ${patrolCaptureTab === 'drone' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      无人机
                    </button>
                    <button 
                      onClick={() => {
                        setPatrolCaptureTab('dog');
                        triggerToast('已切换至【机器狗】超声成像照');
                      }} 
                      className={`py-1 px-1 rounded transition-all font-semibold cursor-pointer ${patrolCaptureTab === 'dog' ? 'bg-teal-500/20 text-teal-300' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      机器狗
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 max-h-[220px] overflow-y-auto pr-1">
                  {initialCaptures
                    .filter(cap => {
                      if (patrolCaptureTab === 'video') return cap.type === 'meter';
                      if (patrolCaptureTab === 'drone') return cap.type === 'aerial';
                      return cap.type === 'thermal';
                    })
                    .map((cap) => (
                      <div key={cap.id} className="bg-slate-950/50 rounded border border-slate-850 overflow-hidden text-left hover:border-slate-500 transition-colors">
                        <div className="relative aspect-video bg-slate-900 border-b border-slate-850 p-2 flex items-center justify-center flex-col justify-between">
                          <div className="text-[14px] font-bold font-mono tracking-tight text-teal-400">{cap.value}</div>
                          <div className="text-[7px] text-[#508890] uppercase font-mono">{cap.name}</div>
                          <span className="absolute top-1 left-2 text-[8px]">
                            {patrolCaptureTab === 'video' ? '📺' : patrolCaptureTab === 'drone' ? '🛸' : '🐕'}
                          </span>
                        </div>
                        <div className="p-1 px-2 flex justify-between items-center text-[8px] text-slate-400">
                          <span className="truncate max-w-[80px] font-semibold">{cap.name}</span>
                          <span className="text-[#518b93]">{cap.time}</span>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </>
          )}

          {/* TAB 5: 故障模拟 (Sim options on right panel as well) */}
          {activeTab === 'simulate' && (
            <>
              {/* Emergency procedures guide index - Frosted Glass Card */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <Activity className="w-4 h-4 text-teal-400" />
                    <span>应急预案</span>
                  </div>
                </div>

                <div className="flex flex-col gap-2.5 text-xs bg-slate-950/20 p-3 rounded-lg border border-slate-850/50 leading-relaxed text-left text-[#89b1bc] font-mono">
                  <div className="border-b border-slate-800 pb-1.5">
                    <h4 className="text-teal-300 font-bold">应急程序 I - 负荷热切除规则:</h4>
                    <p className="mt-1 text-[11px]">温度越过 75°C 稳态红区，系统将在 1500ms 内强制下发联络断路器切离 220V 级三级非保障性动力回路。</p>
                  </div>
                  <div className="border-b border-slate-800 pb-1.5">
                    <h4 className="text-teal-300 font-bold">应急程序 II - 峰谷储能协同削峰法:</h4>
                    <p className="mt-1 text-[11px]">主变总负荷越限 85% 时，通知 1号/2号 站台储能柜自动切换至 “削峰模式”，开启 200kW-350kW 对主变逆变反向能量流补偿。</p>
                  </div>
                  <div>
                    <h4 className="text-teal-300 font-bold">应急程序 III - 算力集群紧急保障程序:</h4>
                    <p className="mt-1 text-[11px]">检测至主线路金属性接地或电压失压，算力中心UPS即时自启接管，同时给柴油备选发电机组启动脉冲，30s内接管100%全负荷电源供应。</p>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* TAB 6: 运维工单列表 (Operations) */}
          {activeTab === 'ops' && (
            <>
              {/* Card 1: 设备维保计划 (Top Right) */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <Calendar className="w-4 h-4 text-teal-400" />
                    <span>设备维保计划</span>
                  </div>
                </div>

                <div className="flex flex-col gap-2 max-h-[190px] overflow-y-auto pr-1">
                  {maintenancePlans.map((plan) => (
                    <div 
                      key={plan.id} 
                      onClick={() => {
                        triggerToast(`计划详情: ${plan.desc}`);
                      }}
                      className="bg-slate-950/40 p-2 rounded border border-slate-850/50 text-left text-xs font-mono flex flex-col gap-1 hover:border-teal-500/50 transition-colors cursor-pointer"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-slate-200 font-bold line-clamp-1">{plan.name}</span>
                        <span className={`px-1.5 py-0.2 rounded text-[8px] border shrink-0 ${
                          plan.status === 'completed' 
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' 
                            : plan.status === 'overdue' 
                            ? 'bg-rose-500/10 border-rose-500/30 text-rose-400' 
                            : 'bg-slate-800 border-slate-700 text-slate-400'
                        }`}>{plan.status === 'completed' ? '已完成' : plan.status === 'overdue' ? '已逾期' : plan.status === 'scheduled' ? '计划中' : '执行中'}</span>
                      </div>
                      <div className="text-[10px] text-slate-500 flex justify-between items-center mt-0.5">
                        <span>维保编号: {plan.id}</span>
                        <span>计划时间: {plan.time}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card 2: 运维报告 (Bottom Right) */}
              <div className="bg-[#040c14]/55 border border-teal-500/15 p-4 rounded-xl shadow-2xl backdrop-blur-md hover:bg-[#040c14]/75 hover:border-teal-400/25 transition-all flex flex-col gap-3 shrink-0">
                <div className="flex items-center justify-between border-b border-teal-500/10 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold tracking-wider">
                    <FileText className="w-4 h-4 text-teal-400" />
                    <span>运维报告</span>
                  </div>
                  <button
                    onClick={() => {
                      const newId = `REP-2026-00${opsReports.length + 1}`;
                      const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
                      const newReport = {
                        id: newId,
                        title: `2026年6月第5周 园区智能配用电及运行评估报告`,
                        time: nowStr,
                        content: `一、基本情况\n截止至 ${nowStr}，园区并网微网系统综合效能评估为优(96.5%)，绿电并网即时消纳，整体负荷峰谷调节作用显著。\n\n二、主要运行缺陷与对标\n1. 1号、20号配用电子系统运行参数保持中高稳态，无重大变温超限。\n2. 各环境巡检测位绝缘阻值稳定恢复。\n\n三、优化运维结论\n系统运转完好！运维一键数孪建模报告完结。`
                      };
                      setOpsReports([newReport, ...opsReports]);
                      triggerToast(`✦ 成功一键生成并导出数孪体检运维报告 [${newId}]！`);
                    }}
                    className="text-[9px] bg-teal-500/20 hover:bg-teal-500/40 border border-teal-500/30 text-teal-300 px-1.5 py-0.5 rounded cursor-pointer transition-all"
                  >
                    生成运维报告
                  </button>
                </div>

                <div className="flex flex-col gap-2.5 max-h-[170px] overflow-y-auto pr-1">
                  {opsReports.map((rep) => (
                    <div key={rep.id} className="bg-slate-950/40 p-2 rounded border border-slate-850/50 text-left text-xs font-mono flex flex-col gap-1">
                      <div className="text-slate-200 font-bold leading-tight line-clamp-1">{rep.title}</div>
                      <div className="text-[10px] text-slate-500 flex justify-between items-center">
                        <span>编号: {rep.id}</span>
                        <span>{rep.time}</span>
                      </div>
                      <div className="flex justify-end gap-1.5 border-t border-slate-900 pt-1.5 mt-0.5">
                        <button
                          onClick={() => setPreviewReport(rep)}
                          className="px-2 py-0.5 text-[9px] bg-teal-500/20 hover:bg-teal-500/40 border border-teal-500/30 text-teal-300 rounded cursor-pointer transition-all animate-none"
                        >
                          预览
                        </button>
                        <button
                          onClick={() => triggerToast(`安全运维报告PDF【${rep.id}】已开始打包下载...`)}
                          className="px-2 py-0.5 text-[9px] bg-emerald-500/20 hover:bg-emerald-500/40 border border-emerald-500/30 text-emerald-300 rounded flex items-center gap-0.5 cursor-pointer transition-all"
                        >
                          <Download className="w-2.5 h-2.5" />
                          <span>下载</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </aside>

        {/* ----------------- MAP CONTROLS DECK HEADER (Layer Legend Switch / 图层图例开关) ----------------- */}
        {activeTab === 'home' && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 pointer-events-auto bg-[#07151f]/85 border border-teal-500/25 rounded-xl px-4 py-2 hover:border-teal-400/40 backdrop-blur-md transition-all duration-300 shadow-2xl flex flex-wrap sm:flex-nowrap items-center gap-3 text-xs font-sans">
            <div className="flex items-center gap-1.5 text-teal-400 font-bold border-r border-teal-500/20 pr-3 mr-1 shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse"></span>
              <span>图层图例</span>
            </div>
            
            {/* 设备POI */}
            <button
              onClick={() => {
                const nextVal = !layerSettings.poi;
                setLayerSettings(prev => ({ ...prev, poi: nextVal }));
                triggerToast(nextVal ? '已开启空间设备三维要素图层显示' : '已隐藏空间设备数据要素图层');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-[11px] font-medium transition-all duration-250 cursor-pointer shrink-0 ${
                layerSettings.poi 
                  ? 'bg-teal-500/15 border-teal-500/45 text-teal-300 shadow-[0_0_8px_rgba(45,212,191,0.2)]' 
                  : 'bg-slate-900/50 border-slate-850 text-slate-400 hover:text-slate-300 hover:border-slate-700'
              }`}
            >
              <MapPin className="w-3.5 h-3.5" />
              <span>设备POI</span>
            </button>

            {/* 电力管线 */}
            <button
              onClick={() => {
                const nextVal = !layerSettings.pipeline;
                setLayerSettings(prev => ({ ...prev, pipeline: nextVal }));
                triggerToast(nextVal ? '已显示电网物理敷管及微网电力管路' : '已关闭全区分布式配电管输结构');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-[11px] font-medium transition-all duration-250 cursor-pointer shrink-0 ${
                layerSettings.pipeline 
                  ? 'bg-teal-500/15 border-teal-500/45 text-teal-300 shadow-[0_0_8px_rgba(45,212,191,0.2)]' 
                  : 'bg-slate-900/50 border-slate-850 text-slate-400 hover:text-slate-300 hover:border-slate-700'
              }`}
            >
              <Route className="w-3.5 h-3.5" />
              <span>电力管线</span>
            </button>

            {/* 能耗热力图 */}
            <button
              onClick={() => {
                const nextVal = !layerSettings.energyHeatmap;
                setLayerSettings(prev => ({ ...prev, energyHeatmap: nextVal }));
                triggerToast(nextVal ? '已开启全区数字能耗热学叠层感知' : '已清退三维热差渲染绘图层');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-[11px] font-medium transition-all duration-250 cursor-pointer shrink-0 ${
                layerSettings.energyHeatmap 
                  ? 'bg-teal-500/15 border-teal-500/45 text-teal-300 shadow-[0_0_8px_rgba(45,212,191,0.2)]' 
                  : 'bg-slate-900/50 border-slate-850 text-slate-400 hover:text-slate-300 hover:border-slate-700'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>能耗热力图</span>
            </button>

            {/* 人流热力图 */}
            <button
              onClick={() => {
                const nextVal = !layerSettings.pedestrianHeatmap;
                setLayerSettings(prev => ({ ...prev, pedestrianHeatmap: nextVal }));
                triggerToast(nextVal ? '已加载人员流线物理驻留密度分布' : '已隐藏全域人流热传检测网络');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-[11px] font-medium transition-all duration-250 cursor-pointer shrink-0 ${
                layerSettings.pedestrianHeatmap 
                  ? 'bg-teal-500/15 border-teal-500/45 text-teal-300 shadow-[0_0_8px_rgba(45,212,191,0.2)]' 
                  : 'bg-slate-900/50 border-slate-850 text-slate-400 hover:text-slate-300 hover:border-slate-700'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>人流热力图</span>
            </button>
          </div>
        )}

        {/* ----------------- DIAGNOSTIC PLACARDS (Floating detail popup) ----------------- */}
        {selectedPoi && isPisVideo && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[360px] rounded-lg p-5 bg-[#08121a]/95 border-2 border-teal-500/40 shadow-[0_0_35px_rgba(45,212,191,0.25)] z-50 animate-fade-in text-left select-none leading-normal">
            <div className="flex items-center justify-between border-b border-teal-500/20 pb-2 mb-3">
              <h3 className="text-sm font-bold text-teal-400 flex items-center gap-1.5 matches-title">
                <Video className="w-4 h-4 text-teal-300 animate-pulse" />
                <span>实时监控视频画面</span>
              </h3>
              <button onClick={() => setSelectedPoi(null)} className="text-slate-400 hover:text-rose-400 text-sm font-bold p-1">✕</button>
            </div>

            {/* Video Feed Screen Box */}
            <div className="relative aspect-video bg-black/95 rounded border border-teal-500/30 overflow-hidden flex flex-col justify-between p-2.5 shadow-inner mb-4">
              {/* Scanline, radar and crosshair overlay */}
              <div className="absolute inset-0 bg-transparent pointer-events-none overflow-hidden">
                <div className="w-full h-[1.5px] bg-teal-500/20 absolute shadow-[0_0_8px_rgba(45,212,191,0.5)] animate-pulse" />
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(45,212,191,0.06)_0%,rgba(0,0,0,0)_80%)]" />
              </div>

              {/* Angle Brackets on 4 corners */}
              <div className="absolute top-2 left-2 w-2 h-2 border-t border-l border-teal-500/60" />
              <div className="absolute top-2 right-2 w-2 h-2 border-t border-r border-teal-500/60" />
              <div className="absolute bottom-2 left-2 w-2 h-2 border-b border-l border-teal-500/60" />
              <div className="absolute bottom-2 right-2 w-2 h-2 border-b border-r border-teal-500/60" />

              {/* Signal Telemetry Label */}
              <div className="absolute top-3 left-3 flex flex-col items-start font-mono text-[8px] text-teal-400/80 leading-tight">
                <span>RESOL: 1920x1080 @ 30fps</span>
                <span>LATENCY &lt; 12ms</span>
                <span>BANDWIDTH: 5.2 Mbps</span>
              </div>

              {/* Pulsing REC Dot */}
              <div className="absolute top-3 right-3 flex items-center gap-1.5 text-[8.5px] bg-red-650/40 text-red-400 border border-red-500/30 px-1.5 py-0.5 rounded leading-none shrink-0 font-mono font-bold animate-pulse">
                <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                <span>REC LIVE</span>
              </div>

              {/* Center Scope Crosshair */}
              <div className="absolute inset-0 flex items-center justify-center opacity-25 pointer-events-none">
                <div className="w-6 h-[1px] bg-teal-400" />
                <div className="h-6 w-[1px] bg-teal-400" />
                <div className="w-8 h-8 border border-teal-400 rounded-full animate-pulse" />
              </div>

              <div /> {/* Spacer */}

              {/* Bottom technology bar with device name */}
              <div className="relative z-10 flex justify-between items-center text-[10px] text-white bg-slate-950/85 p-1 px-2 rounded border border-teal-500/20 font-mono">
                <span className="text-teal-300 font-bold truncate">{selectedPoi.label} ({selectedPoi.id.toUpperCase()})</span>
                <span className="text-emerald-400 font-bold scale-95">STABLE FEED ✔</span>
              </div>
            </div>

            {/* Device metadata display below the feed */}
            <div className="bg-slate-950/40 border border-slate-900/60 rounded p-3 mb-4 text-xs font-mono flex flex-col gap-1.5">
              <div className="flex justify-between border-b border-slate-900/40 pb-1"><span className="text-slate-400">设备名称:</span><span className="font-bold text-slate-100">{selectedPoi.label}</span></div>
              <div className="flex justify-between border-b border-slate-900/40 pb-1"><span className="text-slate-400">设备类型:</span><span className="font-bold text-teal-400">{selectedPoi.category}</span></div>
              <div className="flex justify-between border-b border-slate-900/40 pb-1"><span className="text-slate-400">传输速率:</span><span className="text-teal-400 font-bold">5.2 MB/s</span></div>
              <div className="flex justify-between"><span className="text-slate-400">当前状态:</span><span className="font-bold text-emerald-400 animate-pulse">{selectedPoi.level || '在线运行中'}</span></div>
            </div>

            <div className="flex gap-2 font-mono">
              <button onClick={() => { triggerToast(`已截取并备份 ${selectedPoi.label} 对应的当前帧至云存储空间。`); }} className="flex-1 py-1.5 bg-teal-500/20 hover:bg-teal-500/35 border border-teal-500/40 text-teal-300 rounded text-xs transition-all font-semibold">抓拍画面</button>
              <button onClick={() => setSelectedPoi(null)} className="px-5 py-1.5 bg-slate-900 text-slate-300 rounded text-xs hover:text-rose-400 border border-slate-800 transition-colors">关闭</button>
            </div>
          </div>
        )}

        {selectedPoi && !isPisVideo && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] rounded-lg p-5 bg-[#0b1b24] border-2 border-teal-500/30 shadow-2xl z-50 animate-fade-in text-left select-none leading-normal">
            <div className="flex items-center justify-between border-b border-teal-500/20 pb-2 mb-3">
              <h3 className="text-sm font-bold text-teal-400 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-teal-300" />
                <span>{selectedPoi.label} 数孪诊断</span>
              </h3>
              <button onClick={() => setSelectedPoi(null)} className="text-slate-400 hover:text-rose-400 text-sm font-bold p-1">✕</button>
            </div>

            <div className="grid grid-cols-2 gap-x-4 gap-y-2 border-b border-teal-500/10 pb-3 mb-3 text-xs font-mono">
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">设备分类:</span><span className="font-bold text-slate-200">{selectedPoi.category}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">运行级域:</span><span className="font-bold text-slate-200">{selectedPoi.level}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">瞬时电压:</span><span className="font-bold text-teal-400">{selectedPoi.voltage}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">瞬时电流:</span><span className="font-bold text-teal-400">{selectedPoi.current}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">测得温度:</span><span className="font-bold text-amber-400">{selectedPoi.temp}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">上报时间:</span><span className="font-bold text-slate-400">{selectedPoi.lastCheck}</span></div>
            </div>

            <p className="text-[11px] text-slate-400 font-mono italic">
              系统建议：经多物理量热力耦合算法计算，当前并网载荷一切稳定，可进行削峰填谷智能协同调节。
            </p>

            <div className="flex gap-2 mt-4 font-mono">
              <button onClick={() => setSelectedPoi(null)} className="w-full py-2 bg-[#122c3a]/70 hover:bg-[#122c3a] text-teal-300 font-semibold rounded text-xs border border-teal-500/20 transition-all text-center">关闭</button>
            </div>
          </div>
        )}

        {/* Selected cabinet information detailed placard */}
        {selectedCabinet && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] rounded-lg p-5 bg-[#0b1b24] border-2 border-teal-500/30 shadow-2xl z-50 animate-fade-in text-left select-none leading-normal">
            <div className="flex items-center justify-between border-b border-teal-500/20 pb-2 mb-3">
              <h3 className="text-sm font-bold text-teal-400 flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-teal-300" />
                <span>{selectedCabinet.name} 数孪诊断</span>
              </h3>
              <button onClick={() => setSelectedCabinet(null)} className="text-slate-400 hover:text-rose-400 text-sm font-bold p-1">✕</button>
            </div>

            <div className="grid grid-cols-2 gap-x-4 gap-y-2 border-b border-teal-500/10 pb-3 mb-3 text-xs font-mono">
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">运行分级:</span><span className="font-bold text-slate-200">{selectedCabinet.type}级机柜</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">并网电压:</span><span className="font-bold text-teal-400">{selectedCabinet.voltage}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">分出电流:</span><span className="font-bold text-teal-400">{selectedCabinet.current}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">运行稳态温:</span><span className="font-bold text-amber-500">{selectedCabinet.temp}</span></div>
            </div>

            <div className="flex gap-2 mt-4 font-mono">
              <button onClick={() => { setSelectedCabinet(null); triggerToast('已下达高压隔离协同调控回路指令...'); }} className="flex-1 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 rounded text-xs transition-all font-semibold">远程高压隔离</button>
              <button onClick={() => setSelectedCabinet(null)} className="px-4 py-1.5 bg-slate-900 text-slate-300 rounded text-xs hover:text-rose-400 border border-slate-800 transition-colors">关闭</button>
            </div>
          </div>
        )}

        {/* Selected sub cabinet device detailed popup */}
        {selectedSubCabinetDetail && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] rounded-lg p-5 bg-[#0b1b24] border-2 border-teal-500/30 shadow-2xl z-50 animate-fade-in text-left select-none leading-normal">
            <div className="flex items-center justify-between border-b border-teal-500/20 pb-2 mb-3">
              <h3 className="text-sm font-bold text-teal-400 flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-teal-300" />
                <span>{selectedSubCabinetDetail.name} 运行详情</span>
              </h3>
              <button onClick={() => setSelectedSubCabinetDetail(null)} className="text-slate-400 hover:text-rose-400 text-sm font-bold p-1">✕</button>
            </div>

            <div className="grid grid-cols-2 gap-x-4 gap-y-2 border-b border-teal-500/10 pb-3 mb-3 text-xs font-mono">
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">运行级域:</span><span className="font-bold text-slate-200">{selectedSubCabinetDetail.type}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">当前状态:</span><span className={`font-bold ${selectedSubCabinetDetail.statusColor}`}>{selectedSubCabinetDetail.status}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">瞬时电压:</span><span className="font-bold text-teal-400">{selectedSubCabinetDetail.voltage}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">瞬时电流:</span><span className="font-bold text-teal-400">{selectedSubCabinetDetail.current}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">测得温度:</span><span className="font-bold text-amber-400">{selectedSubCabinetDetail.temp}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">约估负载:</span><span className="font-bold text-slate-300">{selectedSubCabinetDetail.workload}</span></div>
            </div>

            <p className="text-[11px] text-slate-400 font-mono leading-relaxed bg-slate-950/45 p-2.5 border border-slate-800/40 rounded">
              {selectedSubCabinetDetail.desc}
            </p>

            <div className="flex gap-2 mt-4 font-mono">
              <button onClick={() => { setSelectedSubCabinetDetail(null); triggerToast('启动精细化波形仿真计算及红外谱图映射...'); }} className="flex-1 py-1.5 bg-teal-500/20 hover:bg-teal-500/35 border border-teal-500/40 text-teal-300 rounded text-xs transition-all font-semibold">协同仿真分析</button>
              <button onClick={() => setSelectedSubCabinetDetail(null)} className="px-4 py-1.5 bg-slate-900 text-slate-300 rounded text-xs hover:text-rose-400 border border-slate-800 transition-colors">关闭</button>
            </div>
          </div>
        )}

        {/* Selected energy anomaly detailed popup */}
        {selectedEnergyAnomaly && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] rounded-lg p-5 bg-[#120406]/95 border-2 border-rose-500/35 shadow-2xl z-50 animate-fade-in text-left select-none leading-normal">
            <div className="flex items-center justify-between border-b border-rose-500/20 pb-2 mb-3">
              <h3 className="text-sm font-bold text-rose-400 flex items-center gap-1.5 animate-pulse">
                <ShieldAlert className="w-4 h-4 text-rose-300" />
                <span>能耗异常诊断详情</span>
              </h3>
              <button onClick={() => setSelectedEnergyAnomaly(null)} className="text-slate-400 hover:text-rose-400 text-sm font-bold p-1">✕</button>
            </div>

            <div className="flex flex-col gap-1.5 border-b border-rose-500/10 pb-3 mb-3 text-xs font-mono">
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">异常事件:</span><span className="font-bold text-rose-300">{selectedEnergyAnomaly.event}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">严重级别:</span><span className="font-bold text-rose-400">{selectedEnergyAnomaly.level}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">触发阈值:</span><span className="font-bold text-amber-400">{selectedEnergyAnomaly.trigger}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">捕获时间:</span><span className="font-bold text-slate-300">{selectedEnergyAnomaly.time}</span></div>
              <div className="flex justify-between border-b border-slate-900 py-1"><span className="text-slate-400">发生区域:</span><span className="font-bold text-slate-300">{selectedEnergyAnomaly.location}</span></div>
            </div>

            <div className="flex flex-col gap-1.5 text-[11px] leading-relaxed mb-4">
              <div className="text-slate-300 font-bold">诊断说明:</div>
              <div className="text-slate-400 font-mono bg-slate-950/60 p-2 border border-slate-900 rounded">{selectedEnergyAnomaly.detail}</div>
              <div className="text-slate-300 font-bold mt-1">处置建议:</div>
              <div className="text-emerald-400 font-mono">{selectedEnergyAnomaly.solution}</div>
            </div>

            <div className="flex gap-2 font-mono">
              <button onClick={() => { setSelectedEnergyAnomaly(null); triggerToast('已成功通过系统下派工单至当日值班组！'); }} className="flex-1 py-1.5 bg-rose-500/20 hover:bg-rose-500/35 border border-rose-500/40 text-rose-300 rounded text-xs transition-all font-semibold">生成排障工单</button>
              <button onClick={() => setSelectedEnergyAnomaly(null)} className="px-4 py-1.5 bg-slate-900 text-slate-300 rounded text-xs hover:text-rose-400 border border-slate-800 transition-colors">关闭</button>
            </div>
          </div>
        )}

        {/* Alarm Processing (处理) Modal Overlay */}
        {alarmToProcess && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm z-55 flex items-center justify-center p-4">
            <div className="w-full max-w-[360px] bg-[#0b1b24] border-2 border-teal-500/30 shadow-2xl rounded-xl p-5 text-left leading-normal animate-scale-up font-sans">
              <div className="flex items-center justify-between border-b border-teal-500/20 pb-2 mb-4">
                <h3 className="text-sm font-bold text-teal-300 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-rose-400" />
                  <span>处理告警并派发工单</span>
                </h3>
                <button onClick={() => setAlarmToProcess(null)} className="text-slate-400 hover:text-rose-400 text-sm font-bold p-1">✕</button>
              </div>

              {/* Alarm info summary */}
              <div className="bg-slate-950/40 p-2 rounded-lg border border-slate-800/60 mb-4 text-xs font-mono">
                <div className="flex justify-between mb-1">
                  <span className="text-slate-400">告警事件:</span>
                  <span className="font-bold text-rose-400">{alarmToProcess.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">发生位置:</span>
                  <span className="text-slate-300">{alarmToProcess.location}</span>
                </div>
              </div>

              {/* Selection inputs */}
              <div className="space-y-3 text-xs">
                {/* 派发的人员 selector */}
                <div className="flex flex-col gap-1">
                  <label className="text-slate-400 font-bold block">1. 派发运维人员</label>
                  <select
                    value={selectedAssignee}
                    onChange={(e) => setSelectedAssignee(e.target.value)}
                    className="w-full bg-[#07151f] border border-teal-500/20 hover:border-teal-500/40 transition-colors text-slate-200 p-2 rounded focus:outline-none focus:border-teal-400 leading-none h-9 font-mono cursor-pointer"
                  >
                    {['李工 (电力运维)', '张工 (高压电工)', '王工 (中控调度)', '抢修电力二组', '陈技术协助组'].map((name) => (
                      <option key={name} value={name} className="bg-[#0b1b24] text-slate-200">{name}</option>
                    ))}
                  </select>
                </div>

                {/* 任务优先级 selector */}
                <div className="flex flex-col gap-1">
                  <label className="text-slate-400 font-bold block">2. 调度优先级</label>
                  <div className="grid grid-cols-3 gap-2 font-mono">
                    {[
                      { key: 'high', label: '高 (紧急)', border: 'border-rose-500/30 text-rose-400 hover:bg-rose-500/10', active: 'bg-rose-500/20 border-rose-500/60 text-rose-300 font-bold' },
                      { key: 'medium', label: '中 (常规)', border: 'border-amber-500/30 text-amber-400 hover:bg-amber-500/10', active: 'bg-amber-500/20 border-amber-500/60 text-amber-300 font-bold' },
                      { key: 'low', label: '低 (巡检)', border: 'border-teal-500/30 text-teal-400 hover:bg-teal-500/10', active: 'bg-teal-500/20 border-teal-500/60 text-teal-300 font-bold' }
                    ].map((item) => (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() => setSelectedPriority(item.key)}
                        className={`py-1.5 border rounded text-center transition-all cursor-pointer ${
                          selectedPriority === item.key ? item.active : item.border
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 处理备注 textarea */}
                <div className="flex flex-col gap-1">
                  <label className="text-slate-400 font-bold block">3. 处理备注 / 派单说明</label>
                  <textarea
                    value={selectedNotes}
                    onChange={(e) => setSelectedNotes(e.target.value)}
                    placeholder="请输入现场安全交底信息或排查重点指导..."
                    className="w-full h-16 bg-[#07151f] border border-teal-500/20 hover:border-teal-500/40 transition-colors text-slate-300 p-2 rounded focus:outline-none focus:border-teal-400 font-mono resize-none text-[11px]"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2.5 mt-5 font-mono">
                <button
                  type="button"
                  onClick={() => {
                    const priorityLabel = selectedPriority === 'high' ? '高' : selectedPriority === 'medium' ? '中' : '低';
                    const newOrder: WorkOrder = {
                      id: `WO-2026-${Math.floor(100 + Math.random() * 900)}`,
                      title: `【应急抢修】${alarmToProcess.title}`,
                      type: 'fault',
                      status: 'processing',
                      assignee: selectedAssignee,
                      time: '刚刚',
                      priority: selectedPriority,
                      notes: selectedNotes || '常规排查，请现场作业注意高压隔离开关状态。'
                    };
                    setWorkOrders([newOrder, ...workOrders]);
                    
                    // Update current alarm status
                    setAlarms(prevAlarms => 
                      prevAlarms.map(a => a.id === alarmToProcess.id ? { ...a, status: 'processing' } as any : a)
                    );

                    triggerToast(`工单【${newOrder.id}】派发成功！指派至：${selectedAssignee}`);
                    setAlarmToProcess(null);
                  }}
                  className="flex-1 py-1.5 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-bold rounded text-xs transition-all shadow cursor-pointer text-center"
                >
                  确认派发工单
                </button>
                <button
                  type="button"
                  onClick={() => setAlarmToProcess(null)}
                  className="px-4 py-1.5 bg-slate-900 border border-slate-800 text-slate-400 hover:text-rose-400 rounded text-xs hover:bg-slate-950 transition-colors cursor-pointer"
                >
                  取消
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Global Executive report dialog overlay */}
        {showReportType && (
          <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm z-55 flex items-center justify-center p-4">
            <div className="w-full max-w-[500px] bg-[#0b1b24] border-2 border-teal-500/30 rounded-xl p-5 text-left leading-relaxed relative animate-scale-up">
              <div className="flex items-center justify-between border-b border-teal-500/20 pb-3 mb-4">
                <h3 className="text-sm font-bold bg-gradient-to-r from-teal-300 to-emerald-300 bg-clip-text text-transparent flex items-center gap-2">
                  <FileText className="w-5 h-5 text-teal-400" />
                  <span>{showReportType === 'patrol' ? '常规日间巡检数孪测绘报告 — XJ-2026' : '系统自动化微电网运维日报表'}</span>
                </h3>
                <button onClick={() => setShowReportType(null)} className="text-slate-400 hover:text-rose-400 text-sm font-bold p-1">✕</button>
              </div>

              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1 text-xs font-mono select-text bg-slate-950/40 p-4 rounded-lg border border-slate-850/60 shadow-inner">
                {showReportType === 'patrol' ? (
                  <>
                    <section className="space-y-1.5">
                      <h4 className="text-teal-300 font-bold">📋 基本基础信息</h4>
                      <p className="text-slate-400 leading-normal">巡视起止时长：2026-06-08 09:00 至 11:30<br />联合巡检系统：陆基机器人 R1 + 仿生无人机 U1 并网交互</p>
                    </section>
                    <div className="h-px bg-slate-800/80 my-2" />
                    <section className="space-y-1.5">
                      <h4 className="text-teal-300 font-bold">📊 并网核心设备状态量</h4>
                      <p className="text-slate-400 leading-normal">整体系统受巡设备 36 台，全线运行稳定 31 台，系统高载过热或越限报警 5 台。<br />一次柜柜体平均温控稳态为 34.8°C，二次辅助柜体配电站-03局部接触式温度达到最高稳态极限： 72.1°C，超警告阀值。</p>
                    </section>
                    <div className="h-px bg-slate-800/80 my-2" />
                    <section className="space-y-1.5">
                      <h4 className="text-rose-400 font-bold">⚠ 故障与缺陷反馈</h4>
                      <p className="text-slate-400 leading-normal">1. 配电柜-03 发热阻抗变异导致断点微电弧增温 (触及 72.1°C)<br />2. 一次配电柜-05 回路电缆断路故障跳闸中<br />3. 一部绝缘接地铜排在湿季后阻抗突降，为 52MΩ 趋近临界。</p>
                    </section>
                  </>
                ) : (
                  <>
                    <section className="space-y-1.5">
                      <h4 className="text-teal-300 font-bold">📊 全微网并网总机指标</h4>
                      <p className="text-[#96b4be]">并网监控受控站组：360 个节点单元，当前全网稳定在线 344 个节点 (95.6%)，失联探头/离线 16 个，短路等硬跳闸故障 2 个。</p>
                    </section>
                    <div className="h-px bg-slate-800/80 my-2" />
                    <section className="space-y-1.5">
                      <h4 className="text-teal-300 font-bold">⚠ 警迅汇总量</h4>
                      <p className="text-[#96b4be]">当日自动系统拦截、过滤、捕获并网及二次负载高频谐波/接地/过载警报 14 条。已自动或手动调配技术力量处理 11 条，仍剩余 3 组越限紧急警告待现场解决。</p>
                    </section>
                    <div className="h-px bg-slate-800/80 my-2" />
                    <section className="space-y-1.5">
                      <h4 className="text-teal-300 font-bold">⚡ 发用电与集集收益</h4>
                      <p className="text-[#96b4be]">当日累计完成全园区市网侧购用电：3.20 万kWh，光伏并网分布式发集成绿电：0.64 万kWh，储能侧智能协同套保完成削峰：2,100 kWh，节约绿电折合费用：¥824 元。</p>
                    </section>
                  </>
                )}
              </div>

              <div className="flex gap-2.5 mt-5 font-mono">
                <button
                  onClick={() => {
                    setShowReportType(null);
                    triggerToast('数孪自动化报告PDF文档生成，开始下载...');
                  }}
                  className="flex-1 py-1.5 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-bold rounded text-xs transition-all shadow"
                >
                  📥 马上导出成 PDF
                </button>
                <button
                  onClick={() => {
                    setShowReportType(null);
                    triggerToast('自动转化Word矢量公式，开始下载...');
                  }}
                  className="px-3 border border-[#1a4a5e] text-slate-300 rounded hover:bg-slate-900 text-xs"
                >
                  Word 兼容版
                </button>
                <button onClick={() => setShowReportType(null)} className="px-3 border border-slate-800 text-slate-400 hover:text-rose-400 rounded text-xs hover:bg-slate-900 transition-colors">
                  取消
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Preview compiled/saved Operations Report Modal */}
        {previewReport && (
          <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm z-55 flex items-center justify-center p-4">
            <div className="w-full max-w-[500px] bg-[#0b1b24] border-2 border-teal-500/30 rounded-xl p-5 text-left leading-relaxed relative animate-scale-up">
              <div className="flex items-center justify-between border-b border-teal-500/20 pb-3 mb-4">
                <h3 className="text-sm font-bold bg-gradient-to-r from-teal-300 to-emerald-300 bg-clip-text text-transparent flex items-center gap-2">
                  <FileText className="w-5 h-5 text-teal-400" />
                  <span>预览数孪运维体检报告</span>
                </h3>
                <button onClick={() => setPreviewReport(null)} className="text-slate-400 hover:text-rose-400 text-sm font-bold p-1">✕</button>
              </div>

              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1 text-xs font-mono select-text bg-slate-950/40 p-4 rounded-lg border border-slate-850/60 shadow-inner">
                <div className="text-slate-200 font-bold mb-2 pb-1.5 border-b border-slate-800 text-[13px]">{previewReport.title}</div>
                <div className="text-slate-400 text-xs whitespace-pre-wrap leading-relaxed">{previewReport.content}</div>
                <div className="text-[10px] text-slate-500 pt-3 border-t border-slate-900 mt-4 flex justify-between">
                  <span>报告文档ID: {previewReport.id}</span>
                  <span>生成时间: {previewReport.time}</span>
                </div>
              </div>

              <div className="flex gap-2.5 mt-5 font-mono">
                <button
                  onClick={() => {
                    setPreviewReport(null);
                    triggerToast(`报告【${previewReport.id}】PDF下载完成！`);
                  }}
                  className="flex-1 py-1.5 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-bold rounded text-xs transition-all shadow"
                >
                  📥 立即下载 PDF
                </button>
                <button 
                  onClick={() => setPreviewReport(null)} 
                  className="px-4 border border-slate-850 text-slate-400 hover:text-rose-400 rounded text-xs hover:bg-slate-900 transition-colors"
                >
                  关闭
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Global Toast notifications */}
      {toastText && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-55 bg-slate-900/95 border border-teal-400 rounded-lg py-2 px-6 text-xs text-teal-400 shadow-2xl shadow-teal-500/20 font-mono tracking-wide animate-slide-up flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 animate-bounce" />
          <span>{toastText}</span>
        </div>
      )}
    </div>
  );
}
