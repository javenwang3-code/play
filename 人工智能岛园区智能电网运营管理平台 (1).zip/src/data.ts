import { POIPoint, Alarm, WorkOrder, PatrolMetric, CaptureItem } from './types';

export const initialPOIs: POIPoint[] = [
  {
    id: 'poi-1',
    label: '配电站-A',
    category: '一级配电站',
    status: 'warning',
    x: 32,
    y: 45,
    level: '一级',
    voltage: '10kV',
    current: '320A',
    temp: '28.5°C',
    lastCheck: '刚刚'
  },
  {
    id: 'poi-2',
    label: '变压器-T1',
    category: '主变压器',
    status: 'fault',
    x: 48,
    y: 38,
    level: '主变',
    voltage: '10kV/380V',
    current: '450A',
    temp: '42.1°C',
    lastCheck: '刚刚'
  },
  {
    id: 'poi-3',
    label: '充电桩区',
    category: '直流充电桩阵列',
    status: 'normal',
    x: 58,
    y: 52,
    level: '三级',
    voltage: '380V',
    current: '120A',
    temp: '30.2°C',
    lastCheck: '刚刚'
  },
  {
    id: 'poi-4',
    label: '摄像头-01',
    category: '高清防爆鹰眼监控',
    status: 'normal',
    x: 22,
    y: 58,
    level: '感知',
    voltage: '--',
    current: '--',
    temp: '--',
    lastCheck: '10分钟前'
  },
  {
    id: 'poi-5',
    label: '机器狗-R1',
    category: '步进巡检机器人',
    status: 'normal',
    x: 68,
    y: 55,
    level: '运行中',
    voltage: '48V',
    current: '4.5A',
    temp: '38.6°C',
    lastCheck: '持续上报'
  },
  {
    id: 'poi-6',
    label: '无人机-U1',
    category: '多旋翼激光巡扫机',
    status: 'normal',
    x: 45,
    y: 32,
    level: '飞行中',
    voltage: '24V',
    current: '8.2A',
    temp: '33.1°C',
    lastCheck: '3分钟前'
  }
];

export const initialAlarms: Alarm[] = [
  {
    id: 'alt-042',
    title: '配电房-05 回路断路器跳闸',
    level: 'emergency',
    time: '13:02:15',
    location: '20号楼3层',
    tag: '紧急',
    status: 'unprocessed'
  },
  {
    id: 'alt-041',
    title: '配电房-12 电流超出额定值186%',
    level: 'emergency',
    time: '13:01:48',
    location: 'A区变配电室',
    tag: '紧急',
    status: 'unprocessed'
  },
  {
    id: 'alt-040',
    title: '配电房-03 柜体温度过高 (72.1°C)',
    level: 'important',
    time: '12:58:30',
    location: 'B区配电间',
    tag: '重要',
    status: 'confirmed'
  },
  {
    id: 'alt-039',
    title: '摄像头-07 视频信号中断',
    level: 'general',
    time: '12:55:10',
    location: '园区东门',
    tag: '一般',
    status: 'unprocessed'
  }
];

export const initialWorkOrders: WorkOrder[] = [
  {
    id: 'WO-20260608-001',
    title: '配电房-05 断路器故障紧急处理',
    type: 'fault',
    status: 'processing',
    assignee: '张工程师',
    time: '13:05'
  },
  {
    id: 'WO-20260608-002',
    title: 'B区配电房月度例行维保',
    type: 'maintenance',
    status: 'pending',
    assignee: '李工程师',
    time: '14:00'
  },
  {
    id: 'WO-20260608-003',
    title: '无人机高空例行光伏巡扫巡检',
    type: 'patrol',
    status: 'completed',
    assignee: '自动系统',
    time: '10:00'
  }
];

export const patrolRecordsMap: Record<string, PatrolMetric[]> = {
  'xj-20260608': [
    { id: 'm1', name: '仪表读数A', value: '156.3', unit: 'A', status: 'normal' },
    { id: 'm2', name: '一次开关柜温度', value: '35.2', unit: '°C', status: 'normal' },
    { id: 'm3', name: '二次电容柜温度', value: '72.1', unit: '°C', status: 'error' },
    { id: 'm4', name: '防爆接地总电阻', value: '4.2', unit: 'Ω', status: 'normal' },
    { id: 'm5', name: '高频铜排绝缘强度', value: '52', unit: 'MΩ', status: 'warning' },
    { id: 'm6', name: 'SF6六氟化硫密封气压', value: '0.52', unit: 'MPa', status: 'normal' }
  ],
  'xj-20260607': [
    { id: 'm1', name: '仪表读数A', value: '154.8', unit: 'A', status: 'normal' },
    { id: 'm2', name: '一次开关柜温度', value: '34.6', unit: '°C', status: 'normal' },
    { id: 'm3', name: '二次电容柜温度', value: '68.5', unit: '°C', status: 'warning' },
    { id: 'm4', name: '防爆接地总电阻', value: '4.1', unit: 'Ω', status: 'normal' },
    { id: 'm5', name: '高频铜排绝缘强度', value: '55', unit: 'MΩ', status: 'normal' },
    { id: 'm6', name: 'SF6六氟化硫密封气压', value: '0.51', unit: 'MPa', status: 'normal' }
  ],
  'xj-20260606': [
    { id: 'm1', name: '仪表读数A', value: '158.2', unit: 'A', status: 'normal' },
    { id: 'm2', name: '一次开关柜温度', value: '36.1', unit: '°C', status: 'normal' },
    { id: 'm3', name: '二次电容柜温度', value: '45.3', unit: '°C', status: 'normal' },
    { id: 'm4', name: '防爆接地总电阻', value: '4.3', unit: 'Ω', status: 'normal' },
    { id: 'm5', name: '高频铜排绝缘强度', value: '48', unit: 'MΩ', status: 'warning' },
    { id: 'm6', name: 'SF6六氟化硫密封气压', value: '0.50', unit: 'MPa', status: 'normal' }
  ],
  'xj-20260605': [
    { id: 'm1', name: '仪表读数A', value: '153.5', unit: 'A', status: 'normal' },
    { id: 'm2', name: '一次开关柜温度', value: '33.8', unit: '°C', status: 'normal' },
    { id: 'm3', name: '二次电容柜温度', value: '38.2', unit: '°C', status: 'normal' },
    { id: 'm4', name: '防爆接地总电阻', value: '4.0', unit: 'Ω', status: 'normal' },
    { id: 'm5', name: '高频铜排绝缘强度', value: '60', unit: 'MΩ', status: 'normal' },
    { id: 'm6', name: 'SF6六氟化硫密封气压', value: '0.53', unit: 'MPa', status: 'normal' }
  ]
};

export const initialCaptures: CaptureItem[] = [
  // 监控视频
  { id: 'cap-1', name: '电压表盘-A01', value: '384', unit: 'V', time: '09:15', type: 'meter', color: '#2dd4bf' },
  { id: 'cap-2', name: '温度指针-B03', value: '72.1', unit: '°C', time: '09:18', type: 'meter', color: '#fbbf24' },
  { id: 'cap-3', name: '变压器油位-T01', value: '88', unit: '%', time: '09:22', type: 'meter', color: '#34d399' },
  { id: 'cap-4', name: '负载总表-C05', value: '198', unit: 'A', time: '09:25', type: 'meter', color: '#f87171' },
  
  // 无人机
  { id: 'cap-5', name: '10#楼屋顶光伏板', value: '98', unit: '%完好率', time: '10:05', type: 'aerial', color: '#38bdf8' },
  { id: 'cap-6', name: '园区主入口高俯视角', value: '一般路况', unit: '', time: '10:08', type: 'aerial', color: '#2dd4bf' },
  { id: 'cap-7', name: '16#配电房外部外墙', value: '无锈蚀', unit: '', time: '10:12', type: 'aerial', color: '#a78bfa' },
  { id: 'cap-8', name: 'C区电缆排道孔塞', value: '密封良好', unit: '', time: '10:15', type: 'aerial', color: '#34d399' },

  // 机器狗
  { id: 'cap-9', name: '开关接线端子红外', value: '45.2', unit: '°C', time: '11:20', type: 'thermal', color: '#f87171' },
  { id: 'cap-10', name: '主变套管温差热成像', value: '3.2', unit: 'ΔK', time: '11:25', type: 'thermal', color: '#fbbf24' },
  { id: 'cap-11', name: '排线端子汇流条发热', value: '56.3', unit: '°C', time: '11:30', type: 'thermal', color: '#2dd4bf' },
  { id: 'cap-12', name: '电缆排坑防水壁红外', value: '18.5', unit: '°C', time: '11:35', type: 'thermal', color: '#a78bfa' }
];

export const cabinetList = [
  {
    room: '配电房-01',
    cabs: [
      { name: '一级配电柜', type: '一级', status: 'normal', voltage: '380V', current: '156A', temp: '35.2°C' },
      { name: '二级电容补偿柜', type: '二级', status: 'normal', voltage: '380V', current: '142A', temp: '34.8°C' },
      { name: '三级控制联络柜', type: '三级', status: 'warning', voltage: '220V', current: '210A', temp: '45.3°C' }
    ]
  },
  {
    room: '配电房-02',
    cabs: [
      { name: '一级进线柜', type: '一级', status: 'normal', voltage: '380V', current: '165A', temp: '36.1°C' },
      { name: '二级滤波保护柜', type: '二级', status: 'fault', voltage: '380V', current: '0A', temp: '--' },
      { name: '三级智能计量柜', type: '三级', status: 'normal', voltage: '220V', current: '98A', temp: '32.4°C' }
    ]
  },
  {
    room: '配电房-03',
    cabs: [
      { name: '一级双电源切断柜', type: '一级', status: 'normal', voltage: '380V', current: '189A', temp: '33.5°C' },
      { name: '二级有功补偿柜', type: '二级', status: 'warning', voltage: '380V', current: '189A', temp: '72.1°C' },
      { name: '三级终端配电箱', type: '三级', status: 'fault', voltage: '380V', current: '0A', temp: '--' }
    ]
  }
];

export const simulationDetails = {
  outage: {
    title: '停电影响范围模拟',
    results: [
      { label: '故障设备', value: '配电站-A (主变压器)', color: 'text-rose-400' },
      { label: '受影范围', value: 'A区、B区、C区全部范围', color: 'text-amber-400' },
      { label: '停电楼数', value: '5栋 核心业务楼宇', color: 'text-slate-300' },
      { label: '影响企业', value: '12家 (算力中心在内)', color: 'text-slate-300' },
      { label: '影响人数', value: '约 1,840 人', color: 'text-slate-300' },
      { label: '应急备用', value: '柴油发电机将在30秒内应急启动并向算力中心紧急供电', color: 'text-emerald-400' }
    ]
  },
  leakage: {
    title: '线路漏电与短路模拟',
    results: [
      { label: '故障类型', value: '线路短路接地故障及阻抗漏电', color: 'text-rose-400' },
      { label: '故障位置', value: '配电房-03 馈线出线回路', color: 'text-amber-400' },
      { label: '首选保护', value: '速断过流继电保护 110ms 内动作切除故障', color: 'text-emerald-400' },
      { label: '连锁跳闸', value: '下端配电盘 A1-2 馈线保护停电', color: 'text-amber-400' },
      { label: '波及范围', value: 'B区 3至5层 全部弱电及空调线路', color: 'text-slate-300' },
      { label: '停电户数', value: '3家高新研发办公室', color: 'text-slate-300' }
    ]
  },
  overload: {
    title: '设备过载异常模拟',
    results: [
      { label: '稳态载荷', value: '连续运行负载率升至 150%', color: 'text-rose-400' },
      { label: '起始温度', value: '35.0 °C', color: 'text-slate-300' },
      { label: '5-min温升', value: '48.5 °C (温升率极快)', color: 'text-amber-400' },
      { label: '15-min温升', value: '68.2 °C (触及警告值 65°C)', color: 'text-amber-400' },
      { label: '30-min极限', value: '88.6 °C (触发断路器热过载反时限跳闸保护)', color: 'text-rose-400' },
      { label: '调控动作', value: '调度建议：立即切除充电桩区 B1/B2 充电负载 40kW，向储能发令 15kW 辅助放电支撑', color: 'text-emerald-400' }
    ]
  }
};
