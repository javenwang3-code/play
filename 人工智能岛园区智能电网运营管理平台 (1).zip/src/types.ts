export type PointStatus = 'normal' | 'warning' | 'fault';

export interface POIPoint {
  id: string;
  label: string;
  category: string;
  status: PointStatus;
  x: number; // percentage coordinate x (0-100)
  y: number; // percentage coordinate y (0-100)
  level: string;
  voltage: string;
  current: string;
  temp: string;
  lastCheck: string;
}

export type AlarmSeverity = 'emergency' | 'important' | 'general';

export interface Alarm {
  id: string;
  title: string;
  time: string;
  level: AlarmSeverity;
  location: string;
  tag: string;
  status: 'unprocessed' | 'confirmed' | 'processing' | 'resolved';
}

export interface WorkOrder {
  id: string;
  title: string;
  type: 'patrol' | 'maintenance' | 'fault' | 'upgrade';
  status: 'pending' | 'processing' | 'completed';
  assignee: string;
  time: string;
  priority?: string;
  notes?: string;
}

export interface PatrolMetric {
  id: string;
  name: string;
  value: string;
  status: 'normal' | 'warning' | 'error';
  unit: string;
}

export interface CaptureItem {
  id: string;
  name: string;
  value: string;
  unit: string;
  time: string;
  type: 'meter' | 'aerial' | 'thermal';
  color: string;
}
