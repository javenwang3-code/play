import React, { useState, useRef, useEffect } from 'react';
import { POIPoint } from '../types';
import { MapPin, Info, Settings, Wind, Eye } from 'lucide-react';

interface InteractiveMapProps {
  bgImage: string;
  pois: POIPoint[];
  onPoiClick: (poi: POIPoint, e: React.MouseEvent) => void;
  selectedPoiId: string | null;
  showAllPois?: boolean;
  pulseColors?: boolean;
  children?: React.ReactNode;
}

export default function InteractiveMap({
  bgImage,
  pois,
  onPoiClick,
  selectedPoiId,
  showAllPois = true,
  pulseColors = true,
  children
}: InteractiveMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState<number>(1);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Reset viewport when background picture changes
  useEffect(() => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  }, [bgImage]);

  // Handle Mouse Wheel Zoom - focal zooming centered at cursor
  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (!containerRef.current) return;

    const zoomIntensity = 0.12;
    const rect = containerRef.current.getBoundingClientRect();
    
    // Position of cursor relative to container
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Calculate next scale factor (min 0.5x, max 6x)
    const delta = -e.deltaY;
    const nextScale = Math.min(Math.max(scale + (delta > 0 ? 1 : -1) * scale * zoomIntensity, 0.4), 6);

    // Adjust position adjustments to maintain visual point focus
    const scaleRatio = nextScale / scale;
    const nextX = mouseX - (mouseX - position.x) * scaleRatio;
    const nextY = mouseY - (mouseY - position.y) * scaleRatio;

    setScale(nextScale);
    setPosition({ x: nextX, y: nextY });
  };

  // Start dragging pan gesture
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.button !== 0) return; // Only left click drag
    setIsDragging(true);
    setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    setPosition({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Double click resets viewport orientation
  const handleDoubleClick = () => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };

  // Map category status to colors
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'fault': return 'bg-rose-500 border-rose-300 text-rose-500';
      case 'warning': return 'bg-amber-500 border-amber-300 text-amber-500';
      case 'normal':
      default:
        return 'bg-emerald-500 border-emerald-300 text-emerald-500';
    }
  };

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-full overflow-hidden select-none cursor-grab active:cursor-grabbing bg-[#030a0f]`}
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onDoubleClick={handleDoubleClick}
    >
      {/* Zoom indicator on map boundary */}
      <div className="absolute top-4 left-4 z-40 bg-slate-900/80 backdrop-blur-md border border-teal-500/30 rounded px-2.5 py-1 text-xs text-teal-400 font-mono pointer-events-none shadow-md flex items-center gap-1.5">
        <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse"></span>
        <span>数字孪生主控区 · </span>
        <span className="font-bold">{(scale * 100).toFixed(0)}%</span>
        <span className="text-slate-500 text-[10px]"> (双击重置/滚轮缩放/拖拽移动)</span>
      </div>

      {/* Dynamic Digital Twin Scale content */}
      <div
        className="absolute w-full h-full origin-top-left transition-transform duration-75 ease-out"
        style={{
          transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
          backgroundImage: `url(${bgImage})`,
          backgroundPosition: 'center',
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
        }}
      >
        {/* Child canvas maps, heatmaps or SVGs can overlay here */}
        {children}

        {/* Pin points mapped over dynamic relative percentages */}
        {showAllPois && pois.map((poi) => {
          const isActiveColor = getStatusColor(poi.status);
          const isSelected = selectedPoiId === poi.id;

          return (
            <div
              key={poi.id}
              className="absolute group transition-transform duration-200"
              style={{
                left: `${poi.y}%`,
                top: `${poi.x}%`,
                transform: 'translate(-50%, -100%)',
                zIndex: isSelected ? 40 : 15,
              }}
            >
              <div
                className="relative flex flex-col items-center cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  onPoiClick(poi, e);
                }}
              >
                {/* Glowing ring animation */}
                {pulseColors && (
                  <div className={`absolute -top-1 w-7 h-7 rounded-full opacity-60 animate-ping duration-1000 ${
                    poi.status === 'fault' ? 'bg-rose-500' : poi.status === 'warning' ? 'bg-amber-500' : 'bg-emerald-500'
                  }`} />
                )}

                {/* Main pin body */}
                <div className={`w-4 h-4 rounded-full border-2 shadow-lg transition-transform duration-200 relative z-10 ${isActiveColor} ${
                  isSelected ? 'scale-125 ring-2 ring-teal-300' : 'group-hover:scale-110'
                }`}>
                  <div className="absolute inset-1 bg-white rounded-full" />
                </div>

                {/* Futuristic triangular hook anchor */}
                <div className={`w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-t-[6px] relative -top-0.5 z-10 ${
                  poi.status === 'fault' ? 'border-t-rose-500' : poi.status === 'warning' ? 'border-t-amber-500' : 'border-t-emerald-500'
                }`} />

                {/* Point Label panel */}
                <div className={`mt-1.5 px-2 py-0.5 text-[10px] font-medium leading-none text-white rounded border backdrop-blur-md shadow-md whitespace-nowrap select-none transition-all duration-200 ${
                  isSelected 
                    ? 'bg-teal-950/90 border-teal-400 font-semibold scale-105 shadow-teal-500/20' 
                    : 'bg-slate-950/75 border-slate-700/60 group-hover:bg-slate-900 group-hover:border-slate-500'
                }`}>
                  {poi.label}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
