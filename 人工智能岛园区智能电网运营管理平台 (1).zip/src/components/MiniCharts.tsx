import React from 'react';

// === Helper to generate SVG smooth Bezier path ===
function smoothBezierPath(points: { x: number; y: number }[]): string {
  if (points.length === 0) return '';
  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i];
    const p1 = points[i + 1];
    const cpX1 = p0.x + (p1.x - p0.x) / 3;
    const cpY1 = p0.y;
    const cpX2 = p0.x + 2 * (p1.x - p0.x) / 3;
    const cpY2 = p1.y;
    d += ` C ${cpX1} ${cpY1}, ${cpX2} ${cpY2}, ${p1.x} ${p1.y}`;
  }
  return d;
}

// === Donut Chart ===
interface DonutPart {
  value: number;
  color: string;
}

export function DonutChart({ parts, size = 80, strokeWidth = 8, centerText, centerSubtext }: {
  parts: DonutPart[];
  size?: number;
  strokeWidth?: number;
  centerText: string;
  centerSubtext: string;
}) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const total = parts.reduce((acc, p) => acc + p.value, 0);
  
  let accumulatedAngle = -90; // Start at top

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform rotate-0">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="rgba(255,255,255,0.05)"
          strokeWidth={strokeWidth}
        />
        {parts.map((p, idx) => {
          const ratio = p.value / total;
          const strokeLength = circumference * ratio;
          const strokeOffset = circumference - strokeLength;
          const angle = accumulatedAngle;
          accumulatedAngle += ratio * 360;

          return (
            <circle
              key={idx}
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke={p.color}
              strokeWidth={strokeWidth}
              strokeDasharray={`${strokeLength} ${circumference}`}
              strokeDashoffset={strokeOffset}
              transform={`rotate(${angle} ${size / 2} ${size / 2})`}
              strokeLinecap="butt"
              className="transition-all duration-500 ease-in-out"
            />
          );
        })}
      </svg>
      <div className="absolute text-center flex flex-col items-center justify-center leading-none pointer-events-none">
        <span className="text-sm font-bold text-teal-400 font-mono tracking-tight">{centerText}</span>
        <span className="text-[9px] text-[#508890] mt-0.5">{centerSubtext} </span>
      </div>
    </div>
  );
}

// === Area Smooth Bezier Chart ===
interface MultiLineData {
  name: string;
  points: number[];
  color: string;
}

export function MultiLineChart({ data, width = 300, height = 110, showGradient = true, xLabels }: {
  data: MultiLineData[];
  width?: number;
  height?: number;
  showGradient?: boolean;
  xLabels?: string[];
}) {
  const padLeft = 15;
  const padRight = 10;
  const padTop = 15;
  const padBottom = 15;

  const chartW = width - padLeft - padRight;
  const chartH = height - padTop - padBottom;

  // Max value across all items
  const maxVal = Math.max(...data.flatMap(d => d.points), 5);

  return (
    <div className="relative">
      <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible font-mono">
        {/* Horizontal Grids */}
        {[0, 0.5, 1].map((ratio, idx) => {
          const y = padTop + chartH * ratio;
          return (
            <line
              key={idx}
              x1={padLeft}
              y1={y}
              x2={width - padRight}
              y2={y}
              stroke="rgba(80, 136, 144, 0.15)"
              strokeWidth="0.5"
              strokeDasharray="4,4"
            />
          );
        })}

        {/* Generate charts */}
        {data.map((series, sIdx) => {
          const size = series.points.length;
          const points = series.points.map((val, idx) => {
            const x = padLeft + (idx / (size - 1)) * chartW;
            const y = padTop + chartH * (1 - val / maxVal);
            return { x, y };
          });

          const pathD = smoothBezierPath(points);
          
          // Shading polygon under path
          const fillD = points.length > 0 
            ? `${pathD} L ${points[points.length - 1].x} ${padTop + chartH} L ${points[0].x} ${padTop + chartH} Z`
            : '';

          return (
            <g key={sIdx}>
              {showGradient && fillD && (
                <path
                  d={fillD}
                  fill={`url(#grad-${sIdx}-${series.color.replace('#', '')})`}
                  opacity="0.15"
                  className="transition-all duration-500 ease-in-out"
                />
              )}
              {/* Core Path line */}
              <path
                d={pathD}
                fill="none"
                stroke={series.color}
                strokeWidth="1.5"
                strokeLinecap="round"
                className="transition-all duration-500 ease-in-out"
              />
              {/* Dynamic Glow definitions for SVG */}
              <defs>
                <linearGradient id={`grad-${sIdx}-${series.color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={series.color} />
                  <stop offset="100%" stopColor={series.color} stopOpacity="0" />
                </linearGradient>
              </defs>
            </g>
          );
        })}

        {/* Axis Labels */}
        {xLabels && (
          <g>
            {xLabels.map((lbl, idx) => {
              const x = padLeft + (idx / (xLabels.length - 1)) * chartW;
              return (
                <g key={idx} className="text-[8px] fill-[#518b93]">
                  <text x={x} y={height - 2} textAnchor="middle">{lbl}</text>
                  <line x1={x} y1={padTop + chartH} x2={x} y2={padTop + chartH + 3} stroke="rgba(80,136,144,0.3)" />
                </g>
              );
            })}
          </g>
        )}
      </svg>
    </div>
  );
}

// === Multi Bar Double Column Chart ===
export function BarChart({ valuesA, valuesB, width = 300, height = 80, maxVal = 500, labels }: {
  valuesA: number[];
  valuesB: number[];
  width?: number;
  height?: number;
  maxVal?: number;
  labels?: string[];
}) {
  const chartW = width - 20;
  const chartH = height - 20;
  const colSize = valuesA.length;
  const colWidth = chartW / colSize;

  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible font-mono">
      {/* Dynamic columns */}
      {Array.from({ length: colSize }).map((_, idx) => {
        const x = 10 + idx * colWidth;
        const barW = colWidth * 0.3;
        
        const hA = (valuesA[idx] / maxVal) * chartH;
        const hB = (valuesB[idx] / maxVal) * chartH;

        return (
          <g key={idx}>
            {/* Series A Column */}
            <rect
              x={x + colWidth * 0.12}
              y={height - 18 - hA}
              width={barW}
              height={Math.max(1, hA)}
              fill="url(#gradientA)"
              rx="1.5"
              className="transition-all duration-500 ease-in-out"
            />
            {/* Series B Column */}
            <rect
              x={x + colWidth * 0.15 + barW}
              y={height - 18 - hB}
              width={barW}
              height={Math.max(1, hB)}
              fill="url(#gradientB)"
              rx="1.5"
              className="transition-all duration-500 ease-in-out"
            />
            {/* Label */}
            {labels && labels[idx] && (
              <text
                x={x + colWidth / 2}
                y={height - 3}
                className="text-[8px] fill-[#518b93] text-center"
                textAnchor="middle"
              >
                {labels[idx]}
              </text>
            )}
          </g>
        );
      })}

      {/* Grid line boundary */}
      <line x1="10" y1={height - 16} x2={width - 10} y2={height - 16} stroke="rgba(80,136,144,0.25)" strokeWidth="0.5" />

      {/* Gradients */}
      <defs>
        <linearGradient id="gradientA" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2dd4bf" />
          <stop offset="100%" stopColor="#0d5a5a" stopOpacity="0.4" />
        </linearGradient>
        <linearGradient id="gradientB" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#a78bfa" />
          <stop offset="100%" stopColor="#581c87" stopOpacity="0.4" />
        </linearGradient>
      </defs>
    </svg>
  );
}
